class Matrix3
{
public:
    double _00;
    double _01;
    double _02;

    double _10;
    double _11;
    double _12;

    double _20;
    double _21;
    double _22;

    Matrix3( );
};