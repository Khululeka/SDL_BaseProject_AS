//
//#include "../EngineObjects/Math/Vector2.h"
//#include "../EngineObjects/Math/Matrix3.h"
////#include "../../../../../../../../../../AppData/Local/Android/sdk/ndk-bundle/sources/cxx-stl/stlport/stlport/vector"
//
//#include <string>
//#include <map>
//#include <vector>
//#include <iostream>
//#include <fstream>
//#ifndef _WIN32
//#include <sys/param.h>
//#include <dirent.h>
//#else
//#include <Windows.h>
//#endif
//#include <stdio.h>
//
//class Transform // extends Component
//{
//
//private:
//    Transform parent;
//
//    std::vector <Transform> children;
//
//    // local: relative to the parent
//    Vector2 localPosition;//= new Vector2();
//    double localRotation= 0;
//    Vector2 localScale;// = new Vector2(1, 1);
//
//
//    // the transform that converts local coordinates
//    // to world coordinates
//    localToWorldMatrix: Matrix3;// = Matrix3.identity();//todo wel of geen ()??
//    bool isDirty;
//    // specifies if the localToWorldTransform
//    // needs to be recalulated
//
//    // the transform that converts world cooridnates
//    // to local coordinates
// //   worldToLocalMatrix: Matrix3 = Matrix3.identity();
////    isInverseDirty: Bool = false;
//    // specifies if the worldToLocalMatrix
//    // needs to be recalculated
//
//
//    void setDirty();
//
//public:
//    Transform();
//    ~Transform();
//
//    void setParent(Transform value);
//    Transform getParent();
//
//    //Matrix3 calculateLocalToParentMatrix();
//    //Matrix3 getLocalToWorldMatrix();
//    //Matrix3 getWorldToLocalMatrix();
//    Vector2 pointLocalToWorld(Vector2 point)
//    Vector2 pointWorldToLocal(Vector2 point)
//    Vector2 pointTransToLocal(Vector2 point, Transform trans)
//
//
//    Vector2 transformDirection(Vector2 point)
//    Vector2 inverseTransformDirection(Vector2 point)
//
//
//    Vector2 getLocalPosition()
//    //void setLocalPosition(Vector2 point)
//    //void moveLocalPosition(Vector2 point)
//
//    //void setLocalRotation(Float value)
//    //Double getLocalRotation()
//
//    Vector2 getLocalScale()
//    //void setLocalScale(Vector2 point)
//};