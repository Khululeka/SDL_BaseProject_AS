///*
//    // transforms a point from local coordinates to world coordinates
//	-->pointLocalToWorld
//
//    // transforms a point from world coordinates to local coordinates
//	--> pointWorldToLocal
//
//    // transforms a point from @param<Transform> coordinates to local coordinates
//	--> pointTransToLocal
//
//    // sets the position relative to the parent
//	--> setLocalPosition
//
//    // moves the position relative to the current poristion relative to the parent
//	--> moveLocalPosition
//
//*/
//
//
//#include "Transform.h";
//
//// import kha.math.FastMatrix3;
//
//
//
//
//
//Transform::Transform() {
//        children = new Array<Transform>();
//    }
//    /*
//     * Whenever any change happens that changes the localToWorldMatrix
//     * this should be called. That way the next time localToWorldMatrix
//     * is requested it will be recalculated
//     */
//    Transform::~Transform() {
//        //TODO clear arrays / pointers;
//    }
//
//private function setDirty():Void
//            {
//                    // only update dirty boolean if it isn't already dirty
//                    if (!isDirty) {
//                        isDirty = true;
//                        isInverseDirty = true;
//
//                        // set all children to be dirty since any modification
//                        // of a parent transform also effects its children's
//                        // localToWorldTransform
//                        if (children != null) {
//                            for (child in children)  {
//                                child.setDirty();
//                            }
//                        }
//                    }
//            }
//
//    // change the parent transform.
//    // setting it to null makes the
//    // transform a child of world coordinates
//public function setParent(value:Transform):Void {
//            // remove this from the previous parent
//            if (parent != null) {
//                parent.children.remove(this);
//            }
//
//            // assign new parent
//            parent = value;
//            if (parent != null) {//TODO usefull??
//                parent.children.push(this); //TODO was add
//            }
//            setDirty();
//    }
//
//public function getParent():Transform {
//            return parent;
//    }
//
//    // calculates the transform matrix that converts
//    // from local coordinates to the coordinate space
//    // of the parent transform
//public function calculateLocalToParentMatrix():Matrix3 {
//            // Matrix.translate creates a translation matrix
//            // that shifts by (localPosition.x, localPosition.y)
//            // Matrix.rotate rotates by localRotation radians
//            // Matrix.scale scales by a factor of (localScale.x, localScale.y)
//            // These are the basic transforms that are described previously
//            // in this article
//            return Matrix3.translation(localPosition.x, localPosition.y).multmat(
//            Matrix3.rotation(localRotation) ).multmat( Matrix3.scale(localScale.x, localScale.y));
//    }
//
//    // gets the matrix that converts from local
//    // coordinates to world coordinates
//public function getLocalToWorldMatrix():Matrix3{
//            if (isDirty) {
//                if (parent == null) {
//                    // if the parent is null then the parent is
//                    // the world so the localToWorldMatrix
//                    // is the same as local to parent matrix
//                    localToWorldMatrix = calculateLocalToParentMatrix();
//                } else {
//                    // if there is a parent, then the localToWorldMatrix
//                    // is calcualted recursively using the parent's localToWorldMatrix
//                    // concatenated with the local to parent matrix
//                    localToWorldMatrix = parent.getLocalToWorldMatrix().multmat( calculateLocalToParentMatrix() );
//                }
//
//                isDirty = false;
//            }
//
//            return localToWorldMatrix;
//    }
//
//public function getWorldToLocalMatrix():Matrix3 {
//            if (isInverseDirty) {
//                // the worldToLocalMatrix is the inverse of
//                // the localToWorldMatrix
//                worldToLocalMatrix = getLocalToWorldMatrix().inverse();
//                isInverseDirty = false;
//            }
//
//            return worldToLocalMatrix;
//    }
//
//    // transforms a point from local coordinates to world coordinates
//public function pointLocalToWorld(point:Vector2):Vector2 {
//            return getLocalToWorldMatrix().multvec(point);
//    } public function pointLocalToWorldXY(x:Float, y: Float):Vector2 {
//            return getLocalToWorldMatrix().multvec( new Vector2(x, y) );
//    }
//
//    // transforms a point from world coordinates to local coordinates
//public function pointWorldToLocal(point:Vector2):Vector2 {
//            return getWorldToLocalMatrix().multvec(point);
//    } public function pointWorldToLocalXY(x:Float, y: Float):Vector2 {
//            return getWorldToLocalMatrix().multvec( new Vector2(x, y) );
//    }
//
//    // transforms a point from @param<Transform> coordinates to local coordinates
//public function pointTransToLocal(point:Vector2, trans:Transform):Vector2 {
//            return getWorldToLocalMatrix().multvec(trans.pointLocalToWorld(point));
//    }public function pointTransToLocalXY(x:Float, y: Float, trans:Transform):Vector2 {
//            return getWorldToLocalMatrix().multvec(trans.pointLocalToWorld( new Vector2(x, y) ));
//    }
//
//    //TODO maak werkend
//    // transforms a direction from local coordinates to world coordinates
//public function transformDirection(point:Vector2):Vector2 {
//            // matrix multiply padding the extra element with a 0
//            // notice that the worldToLocalMatrix is used here
//            // and the point is multiplied as a row matrix before the
//            // transform matrix. This is the proper way to transform
//            // directions as described before in this article
//
//            // Matrix3x1 transformResult = Matrix3x1(point.x, point.y, 0) * getWorldToLocalMatrix();
//            // return new Vector2(transformResult[1,1], transformResult[2,1], transformResult[3,1]);
//            return getWorldToLocalMatrix().multvec(point);  //todo moet andersom? vec*mat
//    }
//
//    //TODO maak werkend
//    // transforms a direction from world coordinates to local coordinates
//public function inverseTransformDirection(point:Vector2):Vector2 {
//            // same logic as transformDirection only with the inverse of the
//            // inverse localToWorldMatrix which is just the localToWorldMatrix
//
//            // Matrix3x1 transformResult = Matrix3x1(point.x, point.y, 0) * getLocalToWorldMatrix();
//            // return new Vector2(transformResult[1,1], transformResult[2,1], transformResult[3,1]);
//            return getLocalToWorldMatrix().multvec(point);  //todo moet andersom? vec*mat
//    }
//
//
//public function getLocalPosition():Vector2 {
//            return localPosition;
//    }
//
//    // sets the position relative to the parent
//public function setLocalPosition(value:Vector2):Void {
//            setDirty();
//            localPosition = value;
//    } public function setLocalPositionXY(x:Float, y:Float):Void {
//            setDirty();
//            localPosition = new Vector2(x, y);
//    }
//
//    // moves the position relative to the current poristion relative to the parent
//public function moveLocalPosition(value:Vector2):Void {
//            setLocalPosition( localPosition.add(value) );
//    } public function moveLocalPositionXY(x:Float, y:Float):Void {
//            setLocalPosition( localPosition.add( new Vector2(x, y) ) );
//    }
//
//    //TODO perhaps setGlobalPosition etc?
//
//
//public function setLocalRotation(value:Float):Void {
//            setDirty();
//            localRotation = value;
//    }
//public function getLocalRotation():Float {
//            return localRotation;
//    }
//
//public function setLocalScale(value:Vector2):Void {
//            setDirty();
//            localScale = value;
//    }
//public function getLocalScale():Vector2 {
//            return localScale;
//    }
//
//
//
//}
//
//
//
//
//
//
