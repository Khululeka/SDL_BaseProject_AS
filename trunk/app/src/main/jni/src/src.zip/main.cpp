//==============================================================================
/*
	Run the app!

	3/11/2014
    SDLTutorials.com
    Tim Jones
*/
//==============================================================================
#include "App.h"

int main(int argc, char* argv[]) {
	return App::GetInstance()->Execute(argc, argv);
}
