#include"Globals.h"

//TTF_Font* Globals::font = TTF_OpenFont("assets/Fonts/lazy.ttf", 28);
//SDL_Color Globals::textColor = { 0, 0, 0 };
//
//SDL_Window* Globals::window = SDL_CreateWindow(
//	"My SDL Game",
//	SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
//	WindowWidth, WindowHeight, SDL_WINDOW_SHOWN);
//
//SDL_Renderer* Globals::renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
//


TTF_Font* Globals::font = NULL;
SDL_Color Globals::textColor = { 0, 0, 0 };

SDL_Window* Globals::window = NULL;

SDL_Renderer* Globals::renderer = NULL;
