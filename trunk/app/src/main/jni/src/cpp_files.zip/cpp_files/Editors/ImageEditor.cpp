#include "ImageEditor.h"

#include <SDL_image.h>

#include <algorithm>
#include "../Globals.h"


#include <iostream>
#include <fstream>

#include "../ManagersAndControllers/ImageBank.h"

#include "../ManagersAndControllers/Image.h"
#include "../ManagersAndControllers/FileManager.h"
#include "../Helpers/Log.h"
//#include "../Helpers/ConvertFunctions.h"
//#include "../Helpers/Stringify.h"

//#include "../ManagersAndControllers/ImageBank.h"
#include "../ManagersAndControllers/TextureBank.h"


#include "../EngineObjects/ManagersAndControllers/CollisionManager.h"

#include "../ManagersAndControllers/LevelManager.h"

#include <vector>
//using std::vector
#include <string>
//using std::string
#include <stack>

#ifdef _WIN32
#include <Windows.h>
#include <Commdlg.h>
#include <tchar.h>

#endif





//ImageEditor::ImageEditor() { }
ImageEditor::ImageEditor(SDL_Renderer* _renderer) {
	renderer = _renderer;
	
//	editObjectMenu = std::make_unique<Container>();

	//Button* btn; //temp button, all buttons will be held in buttonContainer, some will also be members
	std::unique_ptr<Button> btn;

	//btnOpenImage = new Button("Open Image", Globals::font, Globals::textColor, Globals::renderer);
	//buttonContainer.addChild(btnOpenImage);
	//btnOpenImage->setOnClick(std::bind(&ImageEditor::btnOpenImage_onClick, this));
	//btnOpenImage->setLocalPosition(0, 0);
	btn = std::make_unique<Button>("Open Image", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&ImageEditor::btnOpenImage_onClick, this));
	btn->setLocalPosition(0, 0);
	editObjectMenu->addChild(std::move(btn));

	btn = std::make_unique<Button>("Save Image", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&ImageEditor::btnSaveImage_onClick, this));
	btn->setLocalPosition(0, 50);
	editObjectMenu->addChild(std::move(btn));


	btn = std::make_unique<Button>("Open Level", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&ImageEditor::btnOpenLevel_onClick, this));
	btn->setLocalPosition(0, 0);
	editLevelMenu->addChild(std::move(btn));

	//todo pass funct btnOpenLevel_onClick(int level)
	btn = std::make_unique<Button>("1", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&ImageEditor::btnOpenLevel1_onClick, this));
	btn->setLocalPosition(0, 0);
	openLevelMenu->addChild(std::move(btn));

	btn = std::make_unique<Button>("2", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&ImageEditor::btnOpenLevel2_onClick, this));
	btn->setLocalPosition(0, 30);
	openLevelMenu->addChild(std::move(btn));

	btn = std::make_unique<Button>("3", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&ImageEditor::btnOpenLevel3_onClick, this));
	btn->setLocalPosition(0, 60);
	openLevelMenu->addChild(std::move(btn));

	btn = std::make_unique<Button>("Save Level", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&ImageEditor::btnSaveLevel_onClick, this));
	btn->setLocalPosition(0, 50);
	editLevelMenu->addChild(std::move(btn));


	btn = std::make_unique<Button>("1", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&ImageEditor::btnSaveLevel1_onClick, this));
	btn->setLocalPosition(0, 0);
	saveLevelMenu->addChild(std::move(btn));

	btn = std::make_unique<Button>("2", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&ImageEditor::btnSaveLevel2_onClick, this));
	btn->setLocalPosition(0, 30);
	saveLevelMenu->addChild(std::move(btn));

	btn = std::make_unique<Button>("3", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&ImageEditor::btnSaveLevel3_onClick, this));
	btn->setLocalPosition(0, 60);
	saveLevelMenu->addChild(std::move(btn));



	btn = std::make_unique<Button>("EDIT OBJECT", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&ImageEditor::btnSwitchMode_onClick, this));
	btn->setLocalPosition(0, 0);
	btnSwitchMode = btn.get();
	editingUI.addChild(std::move(btn));

	
//	btn = new Button("Level Editor", Globals::font, Globals::textColor, Globals::renderer);
//	buttonContainer.addChild(btn);
//	btn->setOnClick(std::bind(&ImageEditor::btnOpenImage_onClick, this));
//	btn->setLocalPosition(0, 100);

	openLevelMenu->setLocalPosition(-100, 0);

	editLevelMenu->setLocalPosition(0, 75);
	editObjectMenu->setLocalPosition(0, 75);

	editingUI.addChild(editLevelMenu);
	editingUI.setLocalPosition(600, 100);
}
ImageEditor::~ImageEditor() {

//	clearLevel();
	//todo make editingStage ppointer ...   delete editingStage;
	editingStage.deleteAllContents();
	editingUI.deleteAllContents();

	//TODO delete all corners
//	for (auto &corner : corners) {
//		delete corner;
//	}
//
//	for (auto button : openLevelMenu.getChildren()) {
//		delete button;
//	}
//	for ( auto button : editLevelMenu.getChildren() ) {
//		delete button;
//	}
//	for (auto button : editObjectMenu.getChildren()) {
//		delete button;
//	}

	//if (editingImageTexture) {
	//	SDL_FreeTexture(editingImageTexture);
	//}

	//if (img) { delete img;  }
	//if (tx) { delete tx;  }
	//delete editingImageSprite; //todo should also delete tx and img




	if (editing) {
		editingImageSprite->deleteImageAndTexture();
		SDL_FreeSurface(editingImageSurface);
		SDL_DestroyTexture(txMask);
	}
}

void ImageEditor::clearLevel()
{
	editingStage.deleteAllContents();
}

void ImageEditor::openLevel(int level)
{
	clearLevel();
	editingStage = *LevelManager::openLevel(level);

	//editingStage.setAllChildrenDragable();
	for (auto container : editingStage.getAllChildren_smart()) {
		Sprite* sprite = dynamic_cast<Sprite*> (container);
		if (sprite) { // is child is object of Sprite
			sprite->setDraggable(true);
		}
	}

}

void ImageEditor::openLevel() 
{
	//std::string filePath = FileManager::GetFolderPathFromDialog("F\\Users\\rjv\\Documents\\Programming\\SDL\\vs_projects\\SDL2_Engine\\SDL2_Engine\\assets\\UserData\\Levels");
	
	editingUI.addChild(openLevelMenu);
}
void ImageEditor::saveLevel()
{
	Log("save level");
	editingUI.addChild(saveLevelMenu);
}

void ImageEditor::saveLevel(int level)
{
	Log("save level");

	LevelManager::saveLevel(level, editingStage);
}






void ImageEditor::openImage() 
{

	std::string filePath = FileManager::GetFilePathFromDialog();
	//string filePath = "F\:\\Users\\rjv\\Documents\\Programming\\SDL\\vs_projects\\SDL2_Engine\\SDL2_Engine\\assets\\nope2.png";
	std::string ext = FileManager::GetFilenameExt(filePath);

	if (ext != "png") {
		Log("Error: File was not a PNG")
		return; 
	}


	editingImageSurface = IMG_Load(filePath.c_str());
	if (editingImageSurface->format->format != SDL_PIXELFORMAT_RGBA8888) {
		editingImageSurface = SDL_ConvertSurfaceFormat(editingImageSurface, SDL_PIXELFORMAT_RGBA8888, 0);
	}
	if (editingImageSurface == NULL)
	{
		Log("failed to load image: <%s>", SDL_GetError() );
		return;
	}
	editingColour = { 255,165,0,255 };
	//TODO deze kleur klopt nog niet!

	//4278232575->tael
	//4294944000->orange { 255,165,0,255 }
	editingColourInt = SDL_MapRGBA(editingImageSurface->format, editingColour.r, editingColour.g, editingColour.b, editingColour.a);
	lineWidth = 10;

	//Log("editingColourInt set to <%u>", editingColourInt);




	//todo delete for there new
	Texture* tx = new Texture();
	tx->Load(renderer, filePath );

	Image* img = new Image("editingImageImage", tx);
	editingImageSprite->setImage(img);
	editingStage.addChild(editingImageSprite);
	

	editing = true;


}


//write pixel data to file
void ImageEditor::savePixelDataToCSV(SDL_Surface* surface, std::string outputfile) {
	int width = surface->w;
	int height = surface->h;
	int totalPixels = width * height;

	Uint32 *pixels = (Uint32 *)surface->pixels;

	std::ofstream out(outputfile);
	std::streambuf *coutbuf = std::cout.rdbuf(); //save old buf
	std::cout.rdbuf(out.rdbuf()); //redirect std::cout to out.txt!
	for (int i = 0; i < totalPixels; i++) {
		std::cout << pixels[i] << ";";
		if (i > 0 && (i+1) % width == 0)
		{
			std::cout << "\n";
		}
	}
	std::cout.rdbuf(coutbuf); //reset to standard output again
}



void ImageEditor::saveImage() {
	if (editingImageSurface == NULL)
	{
		Log("failed to load image: <%s>", SDL_GetError());
		return;
	}
	if (editingImageSurface->format->format != SDL_PIXELFORMAT_RGBA8888) {
		editingImageSurface = SDL_ConvertSurfaceFormat(editingImageSurface, SDL_PIXELFORMAT_RGBA8888, 0);
	}
	if (editingImageSurface == NULL)
	{
		Log("failed to set correct format: <%s>", SDL_GetError());
		return;
	}
	

	int pitch = editingImageSurface->pitch;
	int width = editingImageSurface->w;
	int height = editingImageSurface->h;
	int totalPixels = width * height;


	//Create a mask surface from the editing lines. cut averything outside of the lines off the picture.
	//todo refer to window dimensions instead of hardcoded 1024, 768
	SDL_Surface *surfaceMask = SDL_CreateRGBSurface(0, width, height, 32, 0x00ff0000, 0x0000ff00, 0x000000ff, 0xff000000);
	txMask = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 1024, 768);
	SDL_SetRenderTarget(renderer, txMask);
	drawLines();
	


	SDL_Rect editingSurfaceRect = { 0, 0, width, height };
	SDL_RenderReadPixels(renderer, &editingSurfaceRect, SDL_PIXELFORMAT_ARGB8888, surfaceMask->pixels, surfaceMask->pitch);

	//reduce surfaceMask AND editingSurface to contain only unmasked area.

	Uint32 *pixelsSurfaceMask = (Uint32 *)surfaceMask->pixels;
	Uint32 pixelData = 0;
	int topX = 0;
	int topY = 0;
	int bottomX = 0;
	int bottomY = 0;
	for (int x = 0; x < width; x++) {
		for (int y = 0; y < height; y++) {
			pixelData = pixelsSurfaceMask[(x + y * width)];
			if (pixelData > 0) {
				topX = x; 
			} if (pixelData != 0) {break;}
		} if (pixelData != 0) {break;}
	}
	pixelData = 0;
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			pixelData = pixelsSurfaceMask[(x + y * width)];
			if (pixelData > 0) {
					topY = y;
			} if (pixelData != 0) { break; }
		} if (pixelData != 0) { break; }
	}
	pixelData = 0;
	for (int x = width-1; x >= 0; x--) {
		for (int y = height-1; y >= 0; y--) {
			pixelData = pixelsSurfaceMask[(x + y * width)];
			if (pixelData > 0) {
				bottomX = x;
			} if (pixelData != 0) {
				break;
			}
		} if (pixelData != 0) {
			break;
		}
	}
	pixelData = 0;
	for (int y = height-1; y >= 0; y--) {
		for (int x = width-1; x >= 0; x--) {
			pixelData = pixelsSurfaceMask[(x + y * width)];
			if (pixelData > 0) {
				bottomY = y;
			} 
			if (pixelData != 0) {
				break; }
		} 
		if (pixelData != 0) { 
			break; }
	}


	if (bottomX == 0) { bottomX = width ; }
	if (bottomY == 0) { bottomY = height; }

	//add 1 pixel of paddinge for the floodfill
	//TODO what is mask hits 0, w or h edges
	if (bottomX < width) { bottomX++; }
	if (bottomY < height) { bottomY++; }
	if (topX > 0) { topX--; }
	if (topY > 0) { topY--; }

	SDL_Rect surfaceMaskCroppedRect = { topX, topY, bottomX - topX, bottomY - topY };

	Log("topXY<%i><%i><%i><%i>", topX, topY, bottomX, bottomY);
	Log("topXY<%i><%i><%i><%i>", surfaceMaskCroppedRect.x, surfaceMaskCroppedRect.y, surfaceMaskCroppedRect.w, surfaceMaskCroppedRect.h);

	SDL_Surface *surfaceMaskCropped = SDL_CreateRGBSurface(0, surfaceMaskCroppedRect.w, surfaceMaskCroppedRect.h, 32, 0x00ff0000, 0x0000ff00, 0x000000ff, 0xff000000);
	SDL_Surface *editingSurfaceCropped = SDL_CreateRGBSurface(0, surfaceMaskCroppedRect.w, surfaceMaskCroppedRect.h, 32, 0x00ff0000, 0x0000ff00, 0x000000ff, 0xff000000);
	SDL_BlitSurface(surfaceMask   , &surfaceMaskCroppedRect, surfaceMaskCropped   , NULL);
	SDL_BlitSurface(editingImageSurface, &surfaceMaskCroppedRect, editingSurfaceCropped, NULL);

	pitch = editingSurfaceCropped->pitch;
	width = editingSurfaceCropped->w;
	height = editingSurfaceCropped->h;
	totalPixels = width * height;

	Log("topXY<%i><%i><%i>", width, height, totalPixels);


	Uint32 *pixelsMask = (Uint32 *)surfaceMaskCropped->pixels;
	//TODO add one pixel padding all around to be sure all gets floodfilled also when the mask hits the edges
	floodFill(pixelsMask, width, height, 0, 0, 0, editingColourInt);


	SDL_SaveBMP(surfaceMaskCropped, "UserData\\Objects\\screenshot0_mask.bmp"); //todo use const path
	//savePixelDataToCSV(surfaceMaskCropped, "screenshot0_mask.csv");


	SDL_SetRenderDrawColor(renderer, 255, 255, 255, SDL_ALPHA_OPAQUE);
	SDL_SetRenderTarget(renderer, NULL);
//	SDL_DestroyTexture(txSshotSmall);

//	return;

	//some input to give name



//	SDL_LockSurface(editingSurface);
	Uint32 *pixels = (Uint32 *)editingSurfaceCropped->pixels;

	// crash on 4344

	SDL_SaveBMP(editingSurfaceCropped, "UserData\\Objects\\Screenshot1.bmp");
	IMG_SavePNG(editingSurfaceCropped, "UserData\\Objects\\Screenshot1.png");

	for (int i = 0; i < totalPixels; i++) {
			if (pixelsMask[i] != 0) {
				pixels[i] = 0; //TODO how to guard for crashes?
			}
	}

//	for (int x = 0; x < width; x++) {
//		for (int y = 0; y < height; y++) {
//			//Uint32 *target_pixel = ( Uint32 *)editingSurface->pixels + y * editingSurface->pitch + x * sizeof *target_pixel;
//			//*target_pixel = 0;
//
//			//https://stackoverflow.com/questions/20070155/how-to-set-a-pixel-in-a-sdl-surface
//			unsigned char* pixels = (unsigned char*)editingSurface->pixels;
//			pixels[4 * (y * editingSurface->w + x) + 0] = 0;	// >>> blue
//			pixels[4 * (y * editingSurface->w + x) + 1] = 255;	// >>> green
//			pixels[4 * (y * editingSurface->w + x) + 2] = 0;	// >>> red
//			//pixels[4 * (y * editingSurface->w + x) + 3] = 150;	// >>> alpha
//		}
//	}




	// Create the bmp file 
	IMG_SavePNG(editingSurfaceCropped, "UserData\\Objects\\Screenshot2.bmp");


//	SDL_UnlockSurface(editingSurface);
	// Destroy the surface 
//debug toto uncomment	SDL_FreeSurface(editingSurface);
	SDL_FreeSurface(surfaceMask);
	SDL_FreeSurface(surfaceMaskCropped);
	SDL_FreeSurface(editingSurfaceCropped);
	SDL_DestroyTexture(txMask);
}





void ImageEditor::floodFill(Uint32 *pixels, int width, int height, int x, int y, int oldcolor, int newcolor)
{
	if (x < 0 || y < 0) return;
	if (x > width) return;
	if (y > height) return;

	//Uint32 *pixelsToPaint;
	//
	//if (pixels[position] == oldcolor)
	//{
	//	pixels[position] = newcolor;
	//	floodFill(pixels, width, height, x + 1, y, oldcolor, newcolor);
	//	floodFill(pixels, width, height, x, y + 1, oldcolor, newcolor);
	//	floodFill(pixels, width, height, x - 1, y, oldcolor, newcolor);
	//	floodFill(pixels, width, height, x, y - 1, oldcolor, newcolor);
	//}



	struct coordinate { int x, y; };
	std::stack<coordinate> to_draw;
	to_draw.push({ x, y });

	while (!to_draw.empty())
	{
		auto top = to_draw.top();
		to_draw.pop();


		int position = top.x + top.y * width;
		if ((top.x >= 0 && top.x < width)
			&& (top.y >= 0 && top.y < height)
			&& (pixels[position] == oldcolor)
			)
		{
			pixels[position] = newcolor;
			to_draw.push({ top.x, top.y + 1 });
			to_draw.push({ top.x, top.y - 1 });
			to_draw.push({ top.x + 1, top.y });
			to_draw.push({ top.x - 1, top.y });
		}
	}


}

void ImageEditor::update() {

}



void ImageEditor::render() {


	editingStage.render();
	editingUI.render();


}

void ImageEditor::drawLines() {
	for (auto line : lines) {
		line->render();
	}
//	SDL_SetRenderDrawColor(renderer, editingColour.r, editingColour.g, editingColour.b, SDL_ALPHA_OPAQUE);
//
//	Vector2 firstPoint;
//	Vector2 prevPoint;
//
//	int index = 0;
//	for (auto &corner : corners) {
//		Vector2 point = corner->getGlobalPosition();
//
//		if (index <= 0) { firstPoint = point; }
//		else { drawLine(prevPoint, point, lineWidth); }  //SDL_RenderDrawLine(renderer, prevPoint.x, prevPoint.y, point.x, point.y)
//		prevPoint = point;
//		index++;
//	}
//	//SDL_RenderDrawLine(renderer, prevPoint.x, prevPoint.y, firstPoint.x, firstPoint.y);
//	if (corners.size() > 2) {
//		drawLine(prevPoint, firstPoint, lineWidth);
//	}
//	SDL_SetRenderDrawColor(renderer, 255, 255, 255, SDL_ALPHA_OPAQUE);
}
void ImageEditor::drawLine(Vector2 point1, Vector2 point2, int width) 
{
	//todo use gfx to draw better lines...
	int dx = (int)abs(point1.x - point2.x);
	int dy = (int)abs(point1.y - point2.x);

	for (int i = 0; i < width - 1; i++) {
		if (dx > dy) {
			SDL_RenderDrawLine(renderer, (int)point1.x, (int)point1.y + width / 2 - i, (int)point2.x, (int)point2.y + width / 2 - i);

		}
		else {
			SDL_RenderDrawLine(renderer, (int)point1.x + width / 2 - i, (int)point1.y, (int)point2.x + width / 2 - i, (int)point2.y);
		}
	}
}


void ImageEditor::drawCorners() 
{
	//SDL_SetRenderDrawColor(renderer, editingColour.r, editingColour.g, editingColour.b, SDL_ALPHA_OPAQUE);
	//for (auto &point : points) {
	//	if (TextureBank::Get("circle")) {
	//		TextureBank::Get("circle")->Render(point.x-5, point.y-5);  //todo something with anchor
	//	} else {
	//		SDL_Rect rect = { point.x - lineWidth / 2, point.y - lineWidth / 2, lineWidth, lineWidth };
	//		SDL_RenderDrawRect(renderer, &rect);
	//	}
	//}
	//SDL_SetRenderDrawColor(renderer, 255, 255, 255, SDL_ALPHA_OPAQUE);

	for (auto corner : corners) {
		corner->render();
	}

}



void ImageEditor::btnSwitchMode_onClick() 
{
	switch (editingMode) {
	case OBJECT:
		editingMode = LEVEL;
		editingUI.addChild(editLevelMenu);
		editingUI.removeChild(editObjectMenu);
		btnSwitchMode->setText("EDIT OBJECT");
		break;
	case LEVEL:
		editingMode = OBJECT;
		editingUI.addChild(editObjectMenu);
		editingUI.removeChild(editLevelMenu);
		btnSwitchMode->setText("EDIT LEVEL");
		break;
	default: 
		Log("ERROR: switch (editingMode) reached default")
		break;
	}
}

void ImageEditor::btnOpenImage_onClick() 
{
	openImage();
	editingUI.addChild(openLevelMenu);
}



void ImageEditor::btnSaveImage_onClick()
{
	saveImage();
}
void ImageEditor::btnOpenLevel_onClick()
{
	openLevel();
}
void ImageEditor::btnSaveLevel_onClick()
{
	saveLevel();
}

void ImageEditor::btnOpenLevel1_onClick()
{
	editingUI.removeChild(openLevelMenu);
	openLevel(1);
}
void ImageEditor::btnOpenLevel2_onClick()
{
	editingUI.removeChild(openLevelMenu);
	openLevel(2);
}
void ImageEditor::btnOpenLevel3_onClick()
{
	editingUI.removeChild(openLevelMenu);
	openLevel(3);
}

void ImageEditor::btnSaveLevel1_onClick()
{
	editingUI.removeChild(saveLevelMenu);
	saveLevel(1);
}
void ImageEditor::btnSaveLevel2_onClick()
{
	editingUI.removeChild(saveLevelMenu);
	saveLevel(2);
}
void ImageEditor::btnSaveLevel3_onClick()
{
	editingUI.removeChild(saveLevelMenu);
	saveLevel(3);
}


void ImageEditor::OnTouchDown(double x, double y) {
	//Log("ImageEditor->OnTouchDown: %i,%i", mX, mY);
	OnLButtonDown((int)x, (int)y);
}
void ImageEditor::OnTouchUp(double x, double y) {
	//Log("ImageEditor->OnTouchUp: %i,%i", mX, mY);
	OnLButtonUp((int)x, (int)y);
}

void ImageEditor::OnLButtonDown(int x, int y) {
	//Log("ImageEditor->OnLButtonDown: %i,%i", mX, mY);

}
void ImageEditor::OnLButtonUp(int x, int y) {
	//Log("ImageEditor->OnLButtonUp: %i,%i", mX, mY);
	if (!editing) return;
	//dont add a new corner if the mouse is over an existing one.
	for (auto &corner : corners) {
		if (CollisionManager::pointVsRect(Vector2(x, y), corner->getHitzoneRect())) {
			return;
		}
	}

	//add first 3 corners, no needed special action.
	if (corners.size() < 3) {
		//IE_Corner* cornerObj = new IE_Corner(x, y);
		std::shared_ptr<IE_Corner> cornerObj = std::make_unique<IE_Corner>(x, y);
		editingStage.addChild(cornerObj);
		cornerObj->setGlobalPosition(x, y);
		corners.push_back(cornerObj);

		return;
	}



	//find index of closest corner.

	//first set dist to 1st corner.
	Vector2 posMouse = Vector2(x, y);
	Vector2 pos2 = corners[0]->getGlobalPosition();
	int dist = (int)posMouse.sub(pos2).get_length_fast();
	//Log("dist to point1 = %i", dist);

	int dist2;
	int index = 0;
	unsigned indexClosest = 0;
	//Vector2 position_current_corner;

	//then find closest corner
	for (auto &corner : corners) {
		//position_current_corner = corner->getGlobalPosition();
		//dist2 = static_cast<int>( posMouse.sub( corner->getGlobalPosition() ).get_length_fast() );
		dist2 = (int)posMouse.sub(corner->getGlobalPosition()).get_length_fast();
		if (dist2 < dist) {
			dist = dist2;
			indexClosest = index;
			//if (position_current_corner.sub(corners[indexNext]->getGlobalPosition()).get_length_fast() < 
			//	position_current_corner.sub(corners[indexPrev]->getGlobalPosition()).get_length_fast()    ) {
			//	index2ndClosest = index + 1;
			//} else {
			//	index2ndClosest = index - 1;
			//}
		}
		index++;
	}


	//then get next and prev cornern and decide between witch points the mousecursur is.
	unsigned indexNext = indexClosest + 1;
	if (indexNext >= corners.size())
		indexNext = 0;

	int indexPrev = indexClosest - 1;
	if (indexPrev < 0)
		indexPrev = corners.size() - 1;

	Vector2 posCorner = corners[indexClosest]->getGlobalPosition();
	Vector2 posNext   = corners[indexNext]   ->getGlobalPosition();
	Vector2 posPrev   = corners[indexPrev]   ->getGlobalPosition();
	Vector2 cornerToMouse = posCorner.sub(posMouse);
	Vector2 cornerToNext  = posCorner.sub(posNext) ;
	Vector2 cornerToPrev  = posCorner.sub(posPrev) ;

	double angleToMouse = cornerToMouse.get_angle() * 57.2957795131 + 180;
	double angleToNext = cornerToNext  .get_angle() * 57.2957795131 + 180;
	double angleToPrev = cornerToPrev  .get_angle() * 57.2957795131 + 180;
	double angleNext = 180 - abs(abs(angleToMouse - angleToNext) - 180);
	double anglePrev = 180 - abs(abs(angleToMouse - angleToPrev) - 180);

	//Log("angleToMouse: %f", angleToMouse);
	//Log("angleToNext : %f", angleToNext );
	//Log("angleToPrev : %f", angleToPrev );


	std::shared_ptr<IE_Corner> cornerObj = std::make_unique<IE_Corner>(x, y);
	editingStage.addChild(cornerObj);
	cornerObj->setGlobalPosition(x, y);

	if (angleNext > anglePrev) {
		//insert AFTER indexClosest
		if (indexClosest + 1 >= corners.size()) {
			corners.insert(corners.begin() + 0, cornerObj);
		} else {
			corners.insert(corners.begin() + indexClosest + 1, cornerObj);
		}
	} else {
		//insert BEFORE indexClosest
		corners.insert(corners.begin() + indexClosest, cornerObj);
	}

	//TODO test with display of closest, prev net and corner values.










	//create lines
	for (auto line : lines) {
		delete line; //todo neened or not ?
	}
	lines.clear();

	//for (auto corner : corners) {
	//}
	for (unsigned i = 0; i < corners.size(); i++) {
		IE_Line* line = new IE_Line();
		if (i + 1 == corners.size()) {
			line->setPositions(corners[i]->getGlobalPosition(), corners[0]->getGlobalPosition());
		} else {
			line->setPositions(corners[i]->getGlobalPosition(), corners[i + 1]->getGlobalPosition());
		}
		lines.push_back(line);
	}
}



void ImageEditor::OnRButtonDown(int x, int y) {
	//Log("ImageEditor->OnLButtonDown: %i,%i", mX, mY);

}
void ImageEditor::OnRButtonUp(int x, int y) {
	if (!editing) return;

	int index = 0;
	for (auto &corner : corners) {
		Log("index: %i", index);
		index++;
		if (CollisionManager::pointVsRect(Vector2(x, y), corner->getHitzoneRect())) {
			corners.erase(std::remove( corners.begin()  , corners.end() , corner ), corners.end());
			//delete(corner); currently deletes the wrong one!
			//TODO the delete sometimes couses errors the next time corners is iterated.
			//somehow a corner still in corners is deleted?
			//perhaps becouse of the insert when adding new corners?
			//now memleak!

			index = 0;
			for (auto &corner : corners) {
				Log("index: %i", index);
				index++;
			}
			Log("End");

			return;
		}
	}



}



void ImageEditor::OnMouseWheel(int x, int y) {
	if (!editing) return;
	Log("OnMouseWheel: %i, %i", x, y);

//todo set position to zoom in to mouse position
	Vector2 oldScale = editingStage.getLocalScale();
	editingStage.setLocalScale(  oldScale.add( oldScale.dot( Vector2( y * 0.03 ) ) )  );

	//Log("OnMouseWheel: %f", editingStage.getLocalScale().x);


}

void ImageEditor::OnMButtonDown(int x, int y) {
	if (!editing) return;
	dragging = true;
	draggingPosition.set( editingStage.pointWorldToLocal(x, y) );
	//TODO richt position when dragging
}
void ImageEditor::OnMButtonUp(int x, int y) {
	if (!editing) return;
	dragging = false;
	draggingPosition.set(0, 0);
}
void ImageEditor::OnMouseMove(int x, int y, int relX, int relY, bool Left, bool Right, bool Middle) {
	if (dragging) {
		editingStage.setGlobalPosition( Vector2(x, y).sub(draggingPosition) );
	}
}
//TODO add all sprites to Container
//manipulate that container here.

//End up setting size of save image too...



//todo dev temp-> delete later
void ImageEditor::OnKeyUp(SDL_Keysym sym) {
	if (!editing) return;

	switch (sym.sym)
	{
	case SDLK_RETURN:
		Log("keyDown_RETURN");
		saveImage();
		break;

	default:
		Log("keyDown_default");
		break;
	}

}


