

#include "InteractionManager.h"

#include <algorithm>

//#include "../../Helpers/Log.h"
#include "CollisionManager.h"
//#include <vector>

InteractionManager::InteractionManager() { 
	#ifdef _WIN32
		hCursorHand = LoadCursor(NULL, IDC_HAND);
		hCursorArrow = LoadCursor(NULL, IDC_ARROW);
	#endif
}

InteractionManager::~InteractionManager() { }

void InteractionManager::addSprite(Sprite* _sprite) {
	spriteList.push_back(_sprite);
}
void InteractionManager::removeSprite(Sprite* _sprite) {
	spriteList.erase(std::remove(spriteList.begin(), spriteList.end(), _sprite), spriteList.end());
}


//TODO like this, if a InteractiveSprite moves beneath the mouse, without moving the mouse no hand will show.
void InteractionManager::update() {
#ifdef _WIN32
	if (hover) {
		SetCursor(hCursorHand);
	}
	else {
		SetCursor(hCursorArrow);
	}
#endif
}


//void InteractionManager::setMousePosition(Vector2 position) {
//	mousePosition = position;
//}

std::vector<Sprite*> InteractionManager::getHitSprites(Vector2 position) {
	std::vector<Sprite*> _returnList;

	//for (auto &sprite : spriteList) {
	for (unsigned i = spriteList.size(); i-- > 0; ) {
		auto sprite = spriteList[i];
		if (CollisionManager::pointVsRect(position, sprite->getHitzoneRect())) {
			_returnList.push_back(sprite);
			if (!sprite->isClickThrouhable) {
				return _returnList;
			}
		}
	}
	return _returnList;
}



void InteractionManager::OnMouseMove(int x, int y, int relX, int relY, bool Left, bool Right, bool Middle) {
	//for (auto &sprite : getHitSprites(Vector2(mX, mY))) {
	for (auto &sprite : spriteList) {
		sprite->OnMouseMove(x, y, relX, relY, Left, Right, Middle);
	}


#ifdef _WIN32

	hover = false;
	Vector2 mousePosition = Vector2(x, y);
	for (auto &sprite : spriteList) {
		if (CollisionManager::pointVsRect(mousePosition, sprite->getHitzoneRect())) {
			hover = true;
		}
	}


#endif

}


void InteractionManager::OnTouchDown(double x, double y) {
	for (auto &sprite : getHitSprites(Vector2(x, y))) {
		sprite->OnTouchDown(x, y);
	}
}
void InteractionManager::OnTouchUp(double x, double y) {
	for (auto &sprite : getHitSprites(Vector2(x, y))) {
		sprite->OnTouchUp(x, y);
	}
}

void InteractionManager::OnLButtonDown(int x, int y) {
	for (auto &sprite : getHitSprites(Vector2(x, y))) {
		sprite->OnLButtonDown(x, y);
	}
}
void InteractionManager::OnLButtonUp(int x, int y) {
	for (auto &sprite : getHitSprites(Vector2(x, y))) {\
			sprite->OnLButtonUp(x, y);
	}
}


