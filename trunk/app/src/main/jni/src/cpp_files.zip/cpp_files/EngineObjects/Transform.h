#pragma once


#include <cstddef>
#include <vector>
  


#include "Math/Vector2.h"
#include "Math/Matrix3.h"


class Transform // extends Component
{

protected:
	//    // local: relative to the parent
	Vector2 localPosition = Vector2();
	double localRotation = 0;
	Vector2 localScale = Vector2(1, 1);

	Transform* parent = NULL;
	std::vector<Transform*> children;

	
	Matrix3 localToWorldMatrix;				// the transform that converts local coordinates to world coordinates
	bool isDirty = false;					// specifies if the localToWorldTransform needs to be recalulated

	Matrix3 worldToLocalMatrix;				// the transform that converts world cooridnates to local coordinates
	bool isInverseDirty = false;			// specifies if the worldToLocalMatrix needs to be recalulated

	void calcLocalToWorld();
	void calcWorldToLocal();

public:
	Transform();
	virtual ~Transform();


    virtual void setDirty();

    void setParent(Transform* value);
    Transform* getParent();

    Matrix3 calculateLocalToParentMatrix();
    Matrix3 getLocalToWorldMatrix();
    Matrix3 getWorldToLocalMatrix();

	//=============================
	//global <-> local calculations
	Vector2 pointLocalToWorld(Vector2 point);
	Vector2 pointLocalToWorld(double x, double y);
	Vector2 pointWorldToLocal(Vector2 point);
	Vector2 pointWorldToLocal(double x, double y);

	Vector2 pointTransToLocal(Vector2 point, Transform* trans);
	Vector2 pointTransToLocal(double x, double y, Transform* trans);

	Vector2 pointLocalToTrans(Vector2 point, Transform* trans);
	Vector2 pointLocalToTrans(double x, double y, Transform* trans);

	Vector2 transformDirection(Vector2 point);
	Vector2 inverseTransformDirection(Vector2 point);
	//global <-> local calculations
	//=============================

	//=============================
	//get/set position
	Vector2 getLocalPosition();
	Vector2 getGlobalPosition();
	Vector2 getRelativePosition(Transform* trans);
	void setLocalPosition(Vector2 point);
	void setLocalPosition(double x, double y);
	void moveLocalPosition(Vector2 point);
	void moveLocalPosition(double x, double y);

	void setGlobalPosition(Vector2 point);
	void setGlobalPosition(double x, double y);
	void moveGlobalPosition(Vector2 point);
	void moveGlobalPosition(double x, double y);

	//=============================
	//get/set Rotation
	double getLocalRotation();
	double getGlobalRotation();
	double getRelativeRotation(Transform* trans);
	void setLocalRotation(double value);
	void addLocalRotation(double value);

	//=============================
	//get/set Scale
	Vector2 getGlobalScale();
	Vector2 getLocalScale();
	Vector2 getRelativeScale(Transform* trans);
	void setLocalScale(Vector2 point);
	void setLocalScale(double x, double y);
	void setLocalScale(double xy);




};


class TransformManipulationInterface {
public:
	Transform mTransform;
public:

	TransformManipulationInterface() {}
	virtual ~TransformManipulationInterface() {}
	//=============================
	//global <-> local calculations
	virtual Vector2 pointLocalToWorld(Vector2 point) { return mTransform.pointLocalToWorld(point); };
	virtual Vector2 pointLocalToWorld(double x, double y) { return mTransform.pointLocalToWorld(x, y); };
	virtual Vector2 pointWorldToLocal(Vector2 point) { return mTransform.pointWorldToLocal(point); };
	virtual Vector2 pointWorldToLocal(double x, double y) { return mTransform.pointWorldToLocal(x, y); };

	virtual Vector2 pointTransToLocal(Vector2 point, Transform* trans) { return mTransform.pointTransToLocal(point, trans); };
	virtual Vector2 pointTransToLocal(double x, double y, Transform* trans) { return mTransform.pointTransToLocal(x, y, trans); };

	virtual Vector2 pointLocalToTrans(Vector2 point, Transform* trans) { return mTransform.pointLocalToTrans(point, trans); };
	virtual Vector2 pointLocalToTrans(double x, double y, Transform* trans) { return mTransform.pointLocalToTrans(x, y, trans); };

	virtual Vector2 transformDirection(Vector2 point) { return mTransform.transformDirection(point); };
	virtual Vector2 inverseTransformDirection(Vector2 point) { return mTransform.inverseTransformDirection(point); };
	//global <-> local calculations
	//=============================

	//=============================
	//get/set position
	virtual Vector2 getLocalPosition() { return mTransform.getLocalPosition(); };
	virtual Vector2 getGlobalPosition() { return mTransform.getGlobalPosition(); };
	virtual Vector2 getRelativePosition(Transform* trans) { return mTransform.getRelativePosition(trans); };
	virtual void setLocalPosition(Vector2 point) { mTransform.setLocalPosition(point); };
	virtual void setLocalPosition(double x, double y) { mTransform.setLocalPosition(x, y); };
	virtual void moveLocalPosition(Vector2 point) { mTransform.moveLocalPosition(point); };
	virtual void moveLocalPosition(double x, double y) { mTransform.moveLocalPosition(x, y); };

	virtual void setGlobalPosition(Vector2 point) { mTransform.setGlobalPosition(point); };
	virtual void setGlobalPosition(double x, double y) { mTransform.setGlobalPosition(x, y); };
	//virtual void moveGlobalPosition(Vector2 point) { mTransform.moveGlobalPosition(point); };
	//virtual void moveGlobalPosition(double x, double y) { mTransform.moveGlobalPosition(x, y); };

	//=============================
	//get/set Rotation
	virtual double getLocalRotation() { return mTransform.getLocalRotation(); };
	virtual double getGlobalRotation() { return mTransform.getGlobalRotation(); };
	virtual double getRelativeRotation(Transform* trans) { return mTransform.getRelativeRotation(trans); };
	virtual void setLocalRotation(double value) { mTransform.setLocalRotation(value); };
	virtual void addLocalRotation(double value) { mTransform.addLocalRotation(value); };

	//=============================
	//get/set Scale
	virtual Vector2 getGlobalScale() { return mTransform.getGlobalScale(); };
	virtual Vector2 getLocalScale() { return mTransform.getLocalScale(); };
	virtual Vector2 getRelativeScale(Transform* trans) { return mTransform.getRelativeScale(trans); };
	virtual void setLocalScale(Vector2 point) { mTransform.setLocalScale(point); };
	virtual void setLocalScale(double x, double y) { mTransform.setLocalScale(x, y); };
	virtual void setLocalScale(double xy) { mTransform.setLocalScale(xy); };


};