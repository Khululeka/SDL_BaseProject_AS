#ifndef __VECTOR2_H__
#define __VECTOR2_H__


class Vector2
{
private:
	double length;

public:
    double x;
	double y;

	Vector2();
	Vector2(double x, double y);
	Vector2(double xy);

	Vector2 add(Vector2 vec);
	Vector2 add(double x, double y);
	Vector2 sub(Vector2 vec);
	Vector2 sub(double x, double y);
	Vector2 mult(double value);
	Vector2 div(double value);

	double dot(Vector2 vec);

	void set(Vector2 vec);
	void set(double _x, double _y);
	void normalize();
	double get_length_fast();
	double get_length();
	double set_length(double length);


	double get_angle();

};

#endif