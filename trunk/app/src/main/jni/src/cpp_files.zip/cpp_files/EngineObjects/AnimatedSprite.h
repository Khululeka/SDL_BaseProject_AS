#pragma once


#include "BasicSprite.h"
#include "../ManagersAndControllers/Sound.h"
#include "Animation.h"





//TODO remove this class
class AnimatedSprite : public BasicSprite {

public:

	AnimatedSprite();
	~AnimatedSprite();


//	void update();


//	void addState(std::string _name, Animation _animation, Sound* _sound);
//	void setState(std::string stateName);

//	void addAnimation(Animation _animation);
//	void setAnimation(Animation _animation);

protected:



};



