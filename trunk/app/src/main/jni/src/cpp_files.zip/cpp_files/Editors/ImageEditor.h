#pragma once


#include <SDL.h>

#include "IE_Corner.h"
#include "../EngineObjects/Math/Vector2.h"
#include "../EngineObjects/Button.h"
#include "../EngineObjects/Container.h"
#include "../ManagersAndControllers/EventManager.h"

//#include "App.h"  //gives def-int error

enum EDITING_MODE {
	OBJECT,
	LEVEL,
};



class ImageEditor : public EventManager {
private:
	const std::string cObjectPath = "UserData\\Objects\\";
public:
//	ImageEditor(); 
	ImageEditor(SDL_Renderer* _renderer);
	~ImageEditor();



	void update();
	void render();

	SDL_Surface* editingImageSurface;
	//Sprite editingImageSprite;
	std::shared_ptr<BasicSprite> editingImageSprite = std::make_shared<BasicSprite>();

private:
	void drawLines();
	void drawLine(Vector2 point1, Vector2 point2, int width);
	void drawCorners();
	SDL_Renderer* renderer;
	SDL_Surface* srcImg;
	SDL_Texture* editingImageTexture;
	//Image destImg;

	std::vector<IE_Line*> lines; 
	//std::vector<IE_Corner*> corners;
	std::vector< std::shared_ptr<IE_Corner> > corners;

	bool editing = false;
	EDITING_MODE editingMode = LEVEL;


	int editingLevelNumber = 0;

	void openLevel();
	void openLevel(int level);
	void saveLevel();
	void saveLevel(int level);

	void clearLevel();


	void openImage();
	void saveImage();
	void floodFill(Uint32 *pixels, int width, int height, int x, int y, int oldcolor, int newcolor);
	void savePixelDataToCSV(SDL_Surface* surface, std::string outputfile);


	//TODO store pixelformat enum value as variable....
	//int PIXEL_FORMAT = SDL_PIXELFORMAT_RGBA8888;
	SDL_Colour editingColour;
	Uint32 editingColourInt;
	int lineWidth;

	//todo here for debug
	SDL_Texture* txMask;

	bool dragging = false;
	Vector2 draggingPosition;
	Container editingStage;

	Button* btnSwitchMode;
	//std::weak_ptr<Button> btnSwitchMode;


	//Container editObjectMenu;
	//Container editLevelMenu;
	//Container openLevelMenu;
	//Container saveLevelMenu;
	Container editingUI;
	std::shared_ptr<Container> editObjectMenu = std::make_unique<Container>();
	std::shared_ptr<Container> editLevelMenu = std::make_unique<Container>();
	std::shared_ptr<Container> openLevelMenu = std::make_unique<Container>();
	std::shared_ptr<Container> saveLevelMenu = std::make_unique<Container>();

	void btnSwitchMode_onClick();
	void btnOpenImage_onClick();
	void btnSaveImage_onClick();
	void btnOpenLevel_onClick();
	void btnSaveLevel_onClick();

	void btnOpenLevel1_onClick();
	void btnOpenLevel2_onClick();
	void btnOpenLevel3_onClick();

	void btnSaveLevel1_onClick();
	void btnSaveLevel2_onClick();
	void btnSaveLevel3_onClick();
public:

	virtual void OnLButtonDown(int x, int y);
	virtual void OnLButtonUp(int x, int y);

	virtual void OnRButtonDown(int x, int y);
	virtual void OnRButtonUp(int x, int y);

	virtual void OnTouchDown(double x, double y);
	virtual void OnTouchUp(double x, double y);


	virtual void OnMouseWheel(int x, int y);   
	virtual void OnMButtonDown(int x, int y);
	virtual void OnMButtonUp(int x, int y);
	virtual void OnMouseMove(int x, int y, int relX, int relY, bool Left, bool Right, bool Middle);

	//todo dev temp-> delete later
	virtual void OnKeyUp(SDL_Keysym sym);


};
