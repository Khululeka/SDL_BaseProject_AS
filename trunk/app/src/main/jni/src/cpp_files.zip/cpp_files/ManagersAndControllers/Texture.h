//==============================================================================
/*
	Texture class for wrapping SDL Textures

	3/13/2014
    SDLTutorials.com
    Tim Jones
*/
//==============================================================================
#ifndef __TEXTURE_H__
	#define __TEXTURE_H__

#include <SDL.h>
#include <SDL_ttf.h>


#include <string>
#include <vector>

class Texture {
	private:
		std::string Filename;


		std::vector<SDL_Rect> parts;		//TODO redundant right? check and remove

		void free();//todo is free on load really neccicary?


	public:
		//nest 2 should be private
		SDL_Renderer* Renderer = NULL;
		SDL_Texture* SDLTexture = NULL;

		//todo should probably always create with renderer and remove it from load functions
		Texture();
		~Texture();

		int Width = 0; //TODO private?
		int Height = 0;

		bool Load(SDL_Renderer* Renderer, std::string Filename);
		bool loadFromRenderedText(SDL_Renderer* _Renderer, std::string textureText, TTF_Font* font, SDL_Color textColor);

		bool Set(SDL_Renderer* Renderer, SDL_Texture* _SDLTexture);

		void Render(int X, int Y);

		void Render(int X, int Y, SDL_Rect rect);
		void Render(int X, int Y, int Width, int Height, SDL_Rect Source);

		void Render(int X, int Y, int Width, int Height);

		void Render(int X, int Y, int Width, int Height, int SX, int SY, int SWidth, int SHeight);



		void RenderEx(int X, int Y, int Width, int Height, SDL_Rect Source, double rotation);

		void RenderEx(SDL_Rect Destination, SDL_Rect Source, double rotation);

		int GetWidth();
		int GetHeight();
};

#endif
