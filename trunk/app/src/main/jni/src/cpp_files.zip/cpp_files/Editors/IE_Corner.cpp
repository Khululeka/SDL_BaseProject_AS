
#include "IE_Corner.h"

#include "../App.h"
#include "../ManagersAndControllers/TextureBank.h"
#include "../ManagersAndControllers/ImageBank.h"

#include "../Helpers/Log.h"


//todo how to chain constructors or remove this one
//todo this one somehow gets used once on startup????
IE_Corner::IE_Corner() //:
	//Sprite()
{
	if (ImageBank::Get("circle")) {
		setImage(ImageBank::Get("circle"));
	}
	else {
		Log("ERROR: creating IE_Corner without image");
	}
}
IE_Corner::IE_Corner(int x, int y) //:
	//Sprite()
{
	if (ImageBank::Get("circle")) {
		setImage(ImageBank::Get("circle"));
	}
	else {
		Log("ERROR: creating IE_Corner without image");
	}
	setGlobalPosition(x-width/2, y-height/2);
	//setAnchor(0.5);
	draggable = true;


		
}




IE_Line::IE_Line() {
	image = new Image("line", new Texture() );
	//image->tx->SDLTexture = new SDLTexture();

}


//creates texture for this line
//sets position correct for rendering the line

void IE_Line::setPositions(Vector2 point1, Vector2 point2) {

	SDL_Renderer* renderer = image->tx->Renderer;

	image->tx->SDLTexture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 1024, 768);

	SDL_SetRenderTarget(renderer, image->tx->SDLTexture);

	//SDL_FillRect(Surface, NULL, SDLX_RGBAtoPixel(0, 0, 0, 0)); // <<-- this is what clears entire texture 


	//todo use gfx to draw better lines...
	int dx = abs(point1.x - point2.x);
	int dy = abs(point1.y - point2.x);

	for (int i = 0; i < width - 1; i++) {
		if (dx > dy) {
			SDL_RenderDrawLine(renderer, point1.x, point1.y + width / 2 - i, point2.x, point2.y + width / 2 - i);

		}
		else {
			SDL_RenderDrawLine(renderer, point1.x + width / 2 - i, point1.y, point2.x + width / 2 - i, point2.y);
		}
	}
	//set Sprite(this) image to rendered texture.


	//set position to top left corner of rendered texture.
	double x, y;
	if (point1.x < point2.x) { x = point1.x; } else { x = point2.x; }
	if (point1.y < point2.y) { y = point1.y; } else { y = point2.y; }
	setLocalPosition(x, y);


	SDL_SetRenderTarget(renderer, NULL);
}