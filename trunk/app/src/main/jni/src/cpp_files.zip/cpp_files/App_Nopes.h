


//==============================================================================
/*
	Primary application class

	3/11/2014
	SDLTutorials.com
	Tim Jones
*/
//==============================================================================


/*


#ifndef __APPNOPES_H__
	#define __APPNOPES_H__

#include "App.h"
class App_Nopes : public App {  //TODO why public?
private:
//	static App_Nopes Instance;
public:
	void Render();	
//	int Execute(int argc, char* argv[]);

//	static App_Nopes* GetInstance();
};

#endif


*/