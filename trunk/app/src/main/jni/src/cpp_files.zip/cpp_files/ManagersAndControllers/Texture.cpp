//==============================================================================
#include "Texture.h"
#include "../Helpers/Log.h"
#include<iostream>


#include <SDL_image.h>

//==============================================================================
Texture::Texture() {
}

//------------------------------------------------------------------------------
Texture::~Texture() {
	free();
}

void Texture::free() {
	if (SDLTexture) {
		SDL_DestroyTexture(SDLTexture);
		SDLTexture = NULL;
	}
}

//==============================================================================
bool Texture::Load(SDL_Renderer* Renderer, std::string Filename) {
	if(Renderer == NULL) {
		Log("Bad SDL renderer passed");
		return false;
	}
	free();

	this->Renderer = Renderer;
	this->Filename = Filename;

	SDL_Surface* TempSurface = IMG_Load(Filename.c_str());
	if(TempSurface == NULL) {
		Log("Unable to load image : %s : %s", Filename.c_str(), IMG_GetError());
		return false;
	}

    // Convert SDL surface to a texture
	if((SDLTexture = SDL_CreateTextureFromSurface(Renderer, TempSurface)) == NULL) {
		Log("Unable to create SDL Texture : %s : %s", Filename.c_str(), IMG_GetError());
		return false;
	}

    // Grab dimensions
	SDL_QueryTexture(SDLTexture, NULL, NULL, &Width, &Height);

	//Log("Texture Dimensions: %s : %d %d", Filename.c_str(), Width, Height);

	SDL_FreeSurface(TempSurface);

	return true;
}

//==============================================================================
bool Texture::Set(SDL_Renderer* _Renderer, SDL_Texture* _SDLTexture) {
	if (_Renderer == NULL) {
		Log("Bad SDL renderer passed");
		return false;
	}
	if (_SDLTexture == NULL) {
		Log("Bad SDL texture passed");
		return false;
	}
	free();

	Renderer = _Renderer;
	Filename = "";
	SDLTexture = _SDLTexture;


	// Grab dimensions
	SDL_QueryTexture(SDLTexture, NULL, NULL, &Width, &Height);

	return true;
}



bool Texture::loadFromRenderedText(SDL_Renderer* _Renderer, std::string textureText, TTF_Font* font, SDL_Color textColor) {
	if (_Renderer == NULL) {
		Log("Bad SDL renderer passed");
		return false;
	}
	free();

	Renderer = _Renderer;
	Filename = "";

	//Render text surface
	SDL_Surface* textSurface = TTF_RenderText_Solid(font, textureText.c_str(), textColor);
	if (textSurface == NULL)
	{
		printf("Unable to render text surface! SDL_ttf Error: %s\n", TTF_GetError());
	}
	else
	{
		//Create texture from surface pixels
		SDLTexture = SDL_CreateTextureFromSurface(Renderer, textSurface);
		if (SDLTexture == NULL)
		{
			printf("Unable to create texture from rendered text! SDL Error: %s\n", SDL_GetError());
		}
		else
		{
			//Get image dimensions
			Width = textSurface->w;
			Height = textSurface->h;
		}

		//Get rid of old surface
		SDL_FreeSurface(textSurface);
	}

	//Return success
	return SDLTexture != NULL;
}

//render whole texture, no scaling.
//------------------------------------------------------------------------------
void Texture::Render(int X, int Y) {
	Render(X, Y, Width, Height);
}

//render part of texture, no scaling.
//------------------------------------------------------------------------------
void Texture::Render(int X, int Y, SDL_Rect Source) {
	SDL_Rect Destination = { X, Y, Source.w, Source.h };

	SDL_RenderCopy(Renderer, SDLTexture, &Source, &Destination);
}
//render part of texture, with destination width/height.
//------------------------------------------------------------------------------
void Texture::Render(int X, int Y, int Width, int Height, SDL_Rect Source) {
	SDL_Rect Destination = { X, Y, Width, Height };

	SDL_RenderCopy(Renderer, SDLTexture, &Source, &Destination);
}


//render whole texture, with destination width / height.
//------------------------------------------------------------------------------
void Texture::Render(int X, int Y, int Width, int Height) {
	SDL_Rect Destination = {X, Y, Width, Height};

	SDL_RenderCopy(Renderer, SDLTexture, NULL, &Destination);
}

//------------------------------------------------------------------------------
void Texture::Render(int X, int Y, int Width, int Height, int SX, int SY, int SWidth, int SHeight) {
	SDL_Rect Source = {SX, SY, SWidth, SHeight};
	SDL_Rect Destination = {X, Y, Width, Height};

	SDL_RenderCopy(Renderer, SDLTexture, &Source, &Destination);
}



//render part of texture, with destination width/height, rotation
//------------------------------------------------------------------------------
void Texture::RenderEx(int X, int Y, int Width, int Height, SDL_Rect Source, double rotation) {
	SDL_Rect Destination = { X, Y, Width, Height };

	SDL_RenderCopyEx(Renderer, SDLTexture, &Source, &Destination, rotation, NULL, SDL_FLIP_NONE);
}

void Texture::RenderEx(SDL_Rect Destination, SDL_Rect Source, double rotation) {
	SDL_RenderCopyEx(Renderer, SDLTexture, &Source, &Destination, rotation, NULL, SDL_FLIP_NONE);
}



//------------------------------------------------------------------------------
int Texture::GetWidth()  { return Width;  }
int Texture::GetHeight() { return Height; }

//==============================================================================
