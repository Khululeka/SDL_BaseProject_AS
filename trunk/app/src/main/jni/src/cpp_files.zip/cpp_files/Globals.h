#pragma once

#include "App.h"

class Globals {
public:

	static TTF_Font* font;
	static SDL_Color textColor;
	static SDL_Renderer* renderer;
	static SDL_Window* window;

	static const int WindowWidth = 1024;
	static const int WindowHeight = 768;

};