#pragma once

#include "Transform.h"
#include <memory> 

/*
//TODO should this be composition?
A Container isn't truely a Transform, so no. A container should HAVE a Transform.
BUT i want to to things like container->setPosition() and container->setScale().
If Container HAS a Transform, I would have to redirect ALL of these kind of methods to the Transform!
If a Container IS a transform, I dont have to do anything, container->setPosition() automaticly calls Transform::setPosition() for the container object.

So logic says a ontainer should HAVE a Transform.
DRY/KISS/I just dont wat to have to write things like this for EVERY public transform method:
Container::setPosition(Vector2 position) {
	mTransform.setPosition(Vector2 position);
}

*/
class Container 
	: public TransformManipulationInterface//, std::enable_shared_from_this<Container>
{// : public Transform {

public:

//	Container();
	virtual ~Container();

	void deleteAllContents();

	virtual void render();
	virtual void update();
	void render(Transform* camera);

//	void setLocalScale(Vector2 vec);
//	void setLocalScale(double x, double y);
//	void setLocalScale(double xy);


	//std::vector< std::shared_ptr<Container> > getChildren(); 
	std::vector<Container*> getChildren();
	std::vector<Container*> getChildren_smart();

	//Returns all children and all childrens children.
	std::vector<Container*> getAllChildren_smart();  

	//Returns all children and all childrens children.
//	std::vector<Sprite*> getAllSpriteChildren_smart();



	//void addChild1(std::shared_ptr<Container> child);
	//void removeChild(std::shared_ptr<Container> child);
	void addChild_smart(Container* child);
	void removeChild_smart(Container* child);

	void addChild(std::shared_ptr<Container> child);
//	void addChild(Container* child);
	void removeChild(std::shared_ptr<Container> child);
	void removeChild(Container* child);

	void removeChildren();
	void removeChildren_smart();

//	void setAllChildrenDragable();
	//	Matrix3 getLocalToWorldMatrix();
	//	Matrix3 getWorldToLocalMatrix();

protected:
	//void setParent_smart(std::shared_ptr<Container> parent);
	void setParent_smart(Container* parent);
	void setParent(Container* parent);

	Container* mParent;
	std::vector<Container*> mChildren;


	std::weak_ptr<Container> mParent_smart;
	std::vector< std::shared_ptr<Container> > mChildren_smart;
	
};
