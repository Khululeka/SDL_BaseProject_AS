//==============================================================================
/*
	Sound Bank class for loading multiple textures

	3/18/2014
    SDLTutorials.com
    Tim Jones
*/
//==============================================================================
#ifndef __SoundBANK_H__
	#define __SoundBANK_H__

#include <map>
#include <string>

#include "Sound.h"
#include "Music.h"

class SoundBank {
	private:
		static std::map<std::string, Sound*> SoundList;
		static std::map<std::string, Music*> MusicList;

	public:
		static bool Init();

		static void Cleanup();

    private:
        static void AddSound(std::string ID, std::string Filename);
        static void AddMusic(std::string ID, std::string Filename);

	public:
		static Sound* Get(std::string ID);
		static Music* GetMusic(std::string ID);
		static void toggleMusic();

		static SoundBank* GetInstance();
};

#endif
