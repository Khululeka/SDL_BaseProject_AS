//==============================================================================
/*
	Run the app!

	3/11/2014
    SDLTutorials.com
    Tim Jones
*/
//==============================================================================
//#include "App_Nopes.h"
#include "App.h"

int main(int argc, char* argv[]) {
	return App::getInstance()->execute(argc, argv);
//	App_Nopes app;
//	return app.Execute(argc, argv);
}
