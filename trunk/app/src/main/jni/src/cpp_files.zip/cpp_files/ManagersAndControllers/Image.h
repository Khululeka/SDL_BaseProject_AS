#ifndef __IMAGE_H__
#define __IMAGE_H__

#pragma once

#include <SDL.h>

#include <string>

#include "Texture.h"




/* TODO
Image should be extension of texture perhaps.
OR jsut point to an SDL_Texture and forget the texture class.


*/



class Image {

public:
	//Image();
	Image(std::string _id, Texture* _tx); //TODO not used
	Image(std::string _id, Texture* _tx, SDL_Rect _txRect);
	~Image();

	std::string id;
	Texture* tx;
	SDL_Rect txRect;
	void setTexture(Texture* _tx);

	void render(int x, int y);
	void renderEx(int x, int y, double rotation);

	void renderEx(int x, int y, int width, int height, double rotation);


	int getWidth();
	int getHeight();

//	void setPath(std::string _path);
//	std::string getPath();


private:
	int width;
	int height;

//	std::string path;

};


#endif