#include "Sprite.h"

#include "../App.h"  

#include "../Helpers/Log.h"

Sprite::Sprite() {
}

//TODO research inherrit constructor
Sprite::Sprite(Image* img)
{
	setImage(img);
}

Sprite::~Sprite() 
{
	if (mIsInteractive)
		App::getInstance()->getInteractionManager()->removeSprite(this);
}


void Sprite::setInteractive(bool value)
{
	mIsInteractive = value;
	if (mIsInteractive) {
		App::getInstance()->getInteractionManager()->addSprite(this);
	}
	else {
		App::getInstance()->getInteractionManager()->removeSprite(this);
	}
}










//void Sprite::addState(std::string _name, Animation _animation, Sound* _sound) {
////	SpriteState st = { _name, _sound };
//	//stateList[_name] = st;
////	stateList[_name] = { _name, _sound };
//	stateList[_name] = { _name, _animation, _sound };
//}


//void Sprite::setState(std::string stateName) {
//	if (stateList.find(stateName) == stateList.end()) return;
//
//	curState = &stateList[stateName];
//	image = curState->animation.curImage;
//}


//void Sprite::addAnimation(Animation _animation) {
//	animationList.push_back(_animation);
//}




void Sprite::update() {
	Container::update();

	if (curAnimation) {
		curAnimation->update();
		//image = curAnimation->curImage;  //TODO intergratie in update . allow for scale animations etc..
	}

}

//TODO animationList should probably be map with key-value....
//key int or string?
void Sprite::startAnimation(int id)
{
	//TODO add check if animation exists in list.
	curAnimation = animationList[id].get();
	curAnimation->start();
}

//start Animation with ID=id
//Do nothing if that animation doesn't exist
void Sprite::startAnimation(std::string id)
{
	if (animationMap.size() <= 0) return;		
	if (animationMap.find(id) == animationMap.end()) {
		Log("Warning: requested animation ID <%s> not found.", id.c_str());
		return;
	}


	curAnimation = animationMap[id].get();
	curAnimation->start();
}

void Sprite::stopAnimation()
{
	if (curAnimation) {
		curAnimation->stop();
		curAnimation = NULL;
	}
}












void Sprite::setDraggable(bool value)
{
	draggable = value;
}

SDL_Rect Sprite::getHitzoneRect() {
	globalScale = getGlobalScale();
	globalPosition = getGlobalPosition();
	//TODO make smart updates. (on update() when dirty?)

	int globalWidth = static_cast<int>(width * globalScale.x);
	int globalHeight = static_cast<int>(height * globalScale.y);

	SDL_Rect hitZone = { static_cast<int>(globalPosition.x), static_cast<int>(globalPosition.y), globalWidth, globalHeight };
	return hitZone;
}


bool Sprite::isDragging() {
	return draggable;
}


void Sprite::setOnClick(std::function<void(void)> function) {
	//set_OnLButtonUp_callback(function);
	callback_OnLButtonUp = function;
}
void Sprite::setOnClick_returnSelf(std::function<void(Sprite*)> function) {
	//set_OnLButtonUp_callback(function);
	callback_OnLButtonUp_returnSelf = function;
}


void Sprite::OnMouseMove(int x, int y, int relX, int relY, bool Left, bool Right, bool Middle) {
	if (dragging) {
		//moveLocalPosition(relX, relY);
		setGlobalPosition( Vector2(x, y).sub(draggingOffset) );
	}
}
void Sprite::OnLButtonDown(int x, int y) {
	if (draggable) { 
		dragging = true; 
		draggingOffset = pointWorldToLocal( Vector2(x, y) );
	}
}
void Sprite::OnLButtonUp(int x, int y) {
	if (draggable) { dragging = false; }

	//if (callbackClass && callback_OnLButtonUp) {
	//	(*callbackClass.*callback_OnLButtonUp)();
	//}
	if (callback_OnLButtonUp) 
		(callback_OnLButtonUp)();
	
	if (callback_OnLButtonUp_returnSelf) 
		(callback_OnLButtonUp_returnSelf)(this);
	
	
}
void Sprite::OnTouchDown(double x, double y) {
	if (draggable) { dragging = true; }
}
void Sprite::OnTouchUp(double x, double y) {
	if (draggable) { dragging = false; }
}



