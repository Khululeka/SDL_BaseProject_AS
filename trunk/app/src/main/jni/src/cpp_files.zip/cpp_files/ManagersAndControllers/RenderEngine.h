#pragma once

//probably make base Engine interface class?
//also make PhysicsEngine
//MovementEngine????


//Engine that handles all the rendering calls.
//Handles all items that can be rendered (sprites)
//Makes sure all onScreen items' draw functions are called
//Handles offScreen items (they dont have to draw() )


//Add items that should be rendered to this engine.
//Items should have:
//Image* image
//Transform trans
//void Draw();  or directly call image's draw from here?



//std::vector<Sprite> allItems
//std::vector<Sprite> onScreenItems
//periodicly check allItems for items that are on/off screen.

//void render(); //renders all items in onScreenItems



class RenderEngine {
public:
	void render(); //renders all alive sprites
	void update(); //checks (periodicly) for off-screen sprites etc..

private:
	//std::vector<Sprite*> allItems;
	//std::vector<Sprite*> onScreenItems;
	//std::vector<Sprite*> offScreenItems;
};