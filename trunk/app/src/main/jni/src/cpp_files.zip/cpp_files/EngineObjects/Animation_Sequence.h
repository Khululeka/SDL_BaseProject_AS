#pragma once



#include "Animation.h"
#include "../ManagersAndControllers/Image.h"
#include <vector>


class Animation_Sequence : public Animation {

public:
	Animation_Sequence(std::string id, Sprite* sprite, Image* _images[], int speed);
	Animation_Sequence(std::string id, Sprite* sprite, std::vector<Image*> _images, int speed);

	void update() override;
	Image* curImage = NULL;


	void start() override;

private:
	std::vector<Image*> images;
	int speed = 0;//TODO could be in Animation
	int curTick = 0;//TODO could be in Animation
	unsigned curImageIndex = 0;

};