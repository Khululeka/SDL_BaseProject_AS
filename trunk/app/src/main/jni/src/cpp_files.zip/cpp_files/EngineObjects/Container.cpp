#include "Container.h"
//#include "../Helpers/Log.h"
//
//#include <iostream>
//
//#include <string>
//
//#include "ManagersAndControllers/InteractionManager.h"

#include <algorithm>

#include "Sprite.h"
//Container::Container()
//{
//}

Container::~Container()
{
	//todo does Transform get destructor called?
}

void Container::deleteAllContents() 
{
	for (auto child : mChildren) {
		child->deleteAllContents();
	//	try {
//			delete child;
		//} catch .. {
		//	
		//}
	}
	mChildren.clear();
}

std::vector<Container*> Container::getChildren_smart()
{
	std::vector<Container*> returnContainer;
	for (auto child : mChildren_smart) {
		returnContainer.push_back(child.get());
	}
	return returnContainer;
}


std::vector<Container*> Container::getAllChildren_smart()
{
	std::vector<Container*> returnContainer;
	std::vector<Container*> childrenOfChild;
	if (mChildren_smart.size() > 0) {//TODO why is this needed? next line crashes on size==0
		for (auto child : mChildren_smart) {//todo crash als children.size = 0....
			returnContainer.push_back(child.get());
			childrenOfChild = child->getAllChildren_smart();
			returnContainer.insert(std::end(returnContainer), std::begin(childrenOfChild), std::end(childrenOfChild));
		}
	}
	return returnContainer;
}

std::vector<Container*> Container::getChildren()
{
	return mChildren;
}


void Container::setParent_smart(Container* parent) {
	//void Container::setParent(std::shared_ptr<Container> parent) {
	if (parent) {
		std::shared_ptr<Container> pParent(parent);
		mParent_smart = pParent;
		mTransform.setParent(&parent->mTransform);
	}
	else {
		//		mParent = NULL;
		mTransform.setParent(NULL);
	}
}

void Container::setParent(Container* parent) {
//void Container::setParent(std::shared_ptr<Container> parent) {
	if (parent) {
		mParent = parent;
		mTransform.setParent(&parent->mTransform);
	} else {
		mParent = NULL;
		mTransform.setParent(NULL);
	}
}

void Container::addChild_smart(Container* child) {
	std::shared_ptr<Container> mChild(child);
	mChildren_smart.push_back(mChild);
	//child->setParent(shared_from_this());
	child->setParent(this);
}
//void Container::addChild(Container* child) {
//	mChildren.push_back(child);
//	child->setParent(this);
//}
void Container::addChild(std::shared_ptr<Container> child) {
	child->setParent(this);
	//mChildren_smart.push_back(std::move(child));
	mChildren_smart.push_back(child);
}

void Container::removeChild(std::shared_ptr<Container> child) {
	mChildren_smart.erase(std::remove(mChildren_smart.begin(), mChildren_smart.end(), child), mChildren_smart.end());
	child->setParent(NULL);
}
void Container::removeChild(Container* child) {
	mChildren.erase( std::remove(mChildren.begin(), mChildren.end(), child), mChildren.end() );
	child->setParent(NULL);
}
void Container::removeChildren() {
	for (auto renderable : mChildren) {
		renderable->setParent(NULL);
	}
	mChildren.clear();
}

/*TODO
make something to remove from children sprites that are deleted.
*/

void Container::render()
{
	//render all children
	for (auto child : mChildren) {
		child->render();
	}

	for (auto child : mChildren_smart) {
		child->render();
	}
}

void Container::render(Transform* camera)
{
	//render all children
	for (auto child : mChildren) {
		child->render(camera);
	}
}

void Container::update()
{
	//render all children
	for (auto child : mChildren) {
		child->update();
	}

	for (auto child : mChildren_smart) {
		child->update();
	}
}
//void Container::setAllChildrenDragable()
//{
//	for (auto container : mChildren_smart) {
//		container->setAllChildrenDragable();
//		Sprite* sprite = dynamic_cast<Sprite*> (container.get());
//		if (sprite) { // is child is object of Sprite
//			sprite->setDraggable(true);
//		}
//	}
//}