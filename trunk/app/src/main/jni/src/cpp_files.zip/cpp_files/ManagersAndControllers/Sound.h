#pragma once

#include <SDL_mixer.h>
#include <string>

class Sound {
private:
	std::string Filename;

	Mix_Chunk* SDLSound = NULL;
	int curChannel;

public:
	Sound();
	~Sound();

	bool Load(std::string Filename);
	//play once
	void play();
	//start playing loop
	void start();	
	//stop playing loop
	void stop();	
};




