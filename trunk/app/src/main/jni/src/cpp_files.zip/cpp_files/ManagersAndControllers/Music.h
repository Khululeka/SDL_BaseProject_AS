#pragma once



//#include <SDL.h>
#include <SDL_mixer.h>

#include <string>
//#include <vector>


class Music {
private:
	std::string Filename;

	Mix_Music* SDLMusic = NULL;

public:
	Music();
	~Music();

	bool Load(std::string Filename);
	void play();


};





