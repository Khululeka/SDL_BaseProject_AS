#include "AnimatedSprite.h"
#include "../Helpers/Log.h"

#include <iostream>

#include <string>


//#include "../ManagersAndControllers/ImageBank.h"
//#include "../ManagersAndControllers/SoundBank.h"

//std::map<std::string, SpriteState> AnimatedSprite::StateList;


AnimatedSprite::AnimatedSprite() {}

AnimatedSprite::~AnimatedSprite() {}
