//==============================================================================
/*
	Image Bank class for loading multiple Images

	3/18/2014
    SDLTutorials.com
    Tim Jones
*/
//==============================================================================
#ifndef __IMAGEBANK_H__
	#define __IMAGEBANK_H__

#include <map>
#include <string>
#include <vector>

#include "Image.h"


class ImageBank {
	private:
		static std::map<std::string, Image*> ImgList;

	public:
		static bool Init();  //todo not used right now, use loadFolder instead
		static void Cleanup();

    private:
        static void AddImage(std::string ID, Texture* tx, SDL_Rect rect);

	public:
		static Image* Get(std::string ID);
		static ImageBank* GetInstance();

		static bool loadFolder(std::string folder);
		static std::vector<Image*>  getImageList();
};

#endif
