#include "BasicSprite.h"


//#include "../Helpers/Log.h"
//
//#include <iostream>
//
//#include <string>
//
//#include "ManagersAndControllers/InteractionManager.h"
//#include "../ManagersAndControllers/TextureBank.h"




BasicSprite::BasicSprite( )//:
	//Transform()
{
}

BasicSprite::BasicSprite(Image* img)
	: image(img)
	, width( img->getWidth() )
	, height( img->getHeight() )
{

}
BasicSprite::~BasicSprite()
{
	//moved to transform
	//if (parent) {
	//	Container* parentContainer = dynamic_cast<Container*> (parent);
	//	if (parentContainer) { // check if parent's class is Container
	//		parentContainer->removeChild(this);
	//	}
	//}
}


std::string BasicSprite::getID() {
	return image->id;
}

void BasicSprite::deleteImageAndTexture()
{
	delete image->tx;
	delete image;

}

void BasicSprite::setImage(Image* img)
{
	image = img;
	width = img->getWidth();
	height = img->getHeight();

}

void BasicSprite::render()
{
	Container::render();

	if (image) { //TODO perhaps make this redundant 
		Vector2 renderPosition = getGlobalPosition();
		double renderAngle = getGlobalRotation();
		Vector2 renderScale = getGlobalScale();

		width = image->getWidth() * renderScale.x;
		height = image->getHeight() * renderScale.y;

		//convert renderAngle from radians to degrees
		renderAngle = renderAngle * 1 / 0.01745329252;
		image->renderEx(renderPosition.x, renderPosition.y, width, height, renderAngle);
	}
}

void BasicSprite::render(Transform* camera)
{
	if (image) { //TODO perhaps make this redundant 
		//Vector2 renderPosition = pointLocalToTrans(0, 0, camera);
		Vector2 renderPosition = getRelativePosition(camera);
		double renderAngle = getRelativeRotation(camera);
		Vector2 renderScale = getRelativeScale(camera);
		image->render(renderPosition.x, renderPosition.y);
	}
}


void BasicSprite::setLocalScale(Vector2 vec)
{
	TransformManipulationInterface::setLocalScale(vec);

	//useless here gets set at render TODO
	width = image->getWidth() * vec.x;
	height = image->getHeight() * vec.y;
//	Log("W%i, H%i", width, height);
}

void BasicSprite::setLocalScale(double x, double y)
{
	setLocalScale(Vector2(x, y));
}
void BasicSprite::setLocalScale(double xy)
{
	setLocalScale( Vector2(xy, xy) );
}

//////
//////Matrix3 BasicSprite::getLocalToWorldMatrix() {
////	bool recalculate = isDirty;
////	Transform::getLocalToWorldMatrix();
////	
////	if (recalculate) {
////		//relalculate 
////		//globalPosition
////		//globalRotation
////		//globalScale
////		globalPosition = pointLocalToWorld(0, 0);
////		Log("ja");
////
////	}
////
////
////
////	return localToWorldMatrix;
////}
//////
//////Matrix3 BasicSprite::getWorldToLocalMatrix() {
////	bool recalculate = isInverseDirty;
////
////	Transform::getWorldToLocalMatrix();
////
////	if (recalculate) {
////		//TODO add
////	}
////
////
////	return worldToLocalMatrix;
////}


//todo should this go to AnimatedSprite?
//void BasicSprite::setInteractive(bool val) {
//	if (val) {
//		InteractionManager::addSprite(this);
//	} 
//	else {
//		InteractionManager::removeSprite(this);
//	}
//
//}

