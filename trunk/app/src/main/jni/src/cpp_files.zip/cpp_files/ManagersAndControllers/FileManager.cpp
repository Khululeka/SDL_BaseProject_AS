//=============================================================================
#include "FileManager.h"
#include "../Helpers/Log.h"
#include "../Helpers/Stringify.h"

//#include <map>
//#include <iostream>
#include <fstream>

#include <iostream>
//


#ifndef _WIN32
#include <sys/param.h>
#include <dirent.h>
#else
#include <Windows.h>
#include <ShlObj.h>
#endif
#include <stdio.h>


#ifdef __ANDROID__
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <jni.h>
#endif


//=============================================================================
bool FileManager::SetContents(std::string Filename, std::string Content, bool Relative) {
	if(Filename == "") return false;

	if(Relative) Filename = GetCWD() + DIR_SEPARATOR + Filename;

	std::ofstream FileHandle;  //TODO for android make https://wiki.libsdl.org/SDL_RWFromFile

    FileHandle.open(Filename.c_str());
	if(!FileHandle.is_open()) return false;

	FileHandle << Content;
	FileHandle.close();

	return true;
}

//-----------------------------------------------------------------------------
std::string FileManager::GetContents(std::string Filename, bool Relative) {

#ifdef __ANDROID__

    JNIEnv* env=0;
    jobject assetManager=0;

    AAssetManager* pAssetManager = AAssetManager_fromJava(env, assetManager);
	AAsset *pAsset  = AAssetManager_open(pAssetManager, "file.txt", AASSET_MODE_BUFFER);
	if (pAsset )
	{
		const void *res = AAsset_getBuffer(pAsset);
		//do something with the file!
		AAsset_close(pAsset);
	}


    return NULL;

#else
	if(Filename == "") return "";

	if(Relative) Filename = GetCWD() + DIR_SEPARATOR + Filename;

	std::string Content;
	std::ifstream FileHandle;  //TODO for android make https://wiki.libsdl.org/SDL_RWFromFile

    FileHandle.open(Filename.c_str());

	if(FileHandle.is_open()) {
		while(FileHandle.good()) {
			std::string Buffer;
			getline(FileHandle, Buffer);
			if(Buffer == "") continue;

			Content += Buffer + "\n";
		}

		FileHandle.close();
	}

	return Content;
#endif
}



//std::ifstream FileManager::GetContentsStream(std::string FilePath) {
//
//	std::ifstream fileStream;
//
//
//	SDL_RWops* io = SDL_RWFromFile(FilePath.c_str(), "r");
//
//
//
//	Uint8 buf[256];
//	SDL_RWread(io, buf, sizeof(buf), 1);
//	SDL_RWclose(io);
//
//	for (int index = 0; index < 200; ++index) {
//		std::cout << buf[index];
//	}
//
//
//	std::istringstream iss;
//	iss >> buf;
//
//	fileStream >> buf;
//
//	std::cout << iss.rdbuf();
//
//
//	fileStream = std::ifstream(FilePath, std::ifstream::binary);
//	return fileStream;
//
//}


char* FileManager::file_read(std::string filename) {
	return file_read( filename.c_str() );
}

//use SDL_RWops to get file contents.
//copied from https://wiki.libsdl.org/SDL_RWread
char* FileManager::file_read(const char* filename) {

    Log("JSON file: %s", filename);
#ifdef __ANDROID__
    //TODO make function
    //remove leading "assets/" from folder path
    if (filename[0] == 'a') {  //TODO test for full string of "assets/"
        filename += 7;
    }
#endif

    Log("JSON file: %s", filename);

	SDL_RWops *rw = SDL_RWFromFile(filename, "rb");
	if (rw == NULL) return NULL;

	Sint64 res_size = SDL_RWsize(rw);
	char* res = (char*)malloc(res_size + 1);

	Sint64 nb_read_total = 0, nb_read = 1;
	char* buf = res;
	while (nb_read_total < res_size && nb_read != 0) {
		nb_read = SDL_RWread(rw, buf, 1, (res_size - nb_read_total));
		nb_read_total += nb_read;
		buf += nb_read;
	}
	SDL_RWclose(rw);
	if (nb_read_total != res_size) {
		free(res);
		return NULL;
	}

	res[nb_read_total] = '\0';
	return res;
}





//-----------------------------------------------------------------------------
std::vector<std::string> FileManager::GetFilesInFolder(std::string Folder) {


    std::vector<std::string> List;

	std::string CWD  = GetCWD();
	std::string Path = CWD;

	if(Folder != "") Path += DIR_SEPARATOR + Folder;

	#ifdef __APPLE__
		NSError* Error;

		NSString* PathNS			= [NSString stringWithUTF8String:Path.c_str()];
		NSArray* DirectoryContents	= [[NSFileManager defaultManager] contentsOfDirectoryAtPath:PathNS error:&Error];

		for(id File in DirectoryContents) {
			std::string Filename = Path + DIR_SEPARATOR + [File cStringUsingEncoding:1];

			List.push_back(Filename);
		}
	#elif _WIN32
		HANDLE dirHandle = NULL;
		WIN32_FIND_DATA FileHandle;
		std::string winPath(Path + DIR_SEPARATOR + std::string("*"));
		if ((dirHandle = FindFirstFile(winPath.c_str(), &FileHandle)) != INVALID_HANDLE_VALUE)
		{
			do
			{
				if (std::string(FileHandle.cFileName) == ".") continue;
				if (std::string(FileHandle.cFileName) == "..") continue;

				std::string Filename = Path + DIR_SEPARATOR + FileHandle.cFileName;

				List.push_back(Filename);
			} while (FindNextFile(dirHandle, &FileHandle) != false);
			FindClose(dirHandle);
		}
		else
		{
			Log("Unable to open directory: %s", Path.c_str());
		}
    #elif __ANDROID__

    //remove leading "assets/" from folder path
    if (Folder.find("assets/") == 0) {
        Folder.erase(0,7);
    }

    Log("Checking folder: %s", Folder.c_str());

    bool directories = false;
    bool files = true;

    if(Folder.size() > 0 && Folder[0] == '/')  // Absolute file name, not an asset
    {
  //      List = ioListUsingOpendir(dirname, directories, files);
    }
    else  // Look in assets
    {
        // retrieve the JNI environment.
        JNIEnv* env = (JNIEnv*)SDL_AndroidGetJNIEnv();

        // retrieve the Java instance of the SDLActivity
        jobject activity = (jobject)SDL_AndroidGetActivity();

        // find the Java class of the activity. It should be SDLActivity or a subclass of it.
        jclass clazz( env->GetObjectClass(activity) );

        // find the identifier of the method to call
        jmethodID method_id = env->GetMethodID( clazz, "list_assets", "(Ljava/lang/String;ZZ)[Ljava/lang/String;" );

        // Prepare Java arguments
        char* path_str_storage = new char[Folder.size()+1];
        strcpy(path_str_storage, Folder.c_str());
        jstring path_str = env->NewStringUTF(path_str_storage);
        jboolean dirs_j = directories;
        jboolean files_j = files;

        // call the Java method
        jobjectArray stringArrays = (jobjectArray) env->CallObjectMethod( activity, method_id, path_str, dirs_j, files_j);

        delete[] path_str_storage;

        int size = env->GetArrayLength(stringArrays);
        for(int i = 0; i < size; i++)
        {
            jstring string = (jstring) env->GetObjectArrayElement(stringArrays, i);
            const char* myarray = env->GetStringUTFChars(string, 0);

            List.push_back(myarray);

            env->ReleaseStringUTFChars(string, myarray);
            env->DeleteLocalRef(string);
        }
        // clean up the local references.
        env->DeleteLocalRef(activity);
    }







//https://en.wikibooks.org/wiki/OpenGL_Programming/Android_GLUT_Wrapper#Accessing_assets
  //  jobject assetManager = state_param->activity->assetManager;
  //  AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
//
  //  AAssetDir* assetDir = AAssetManager_openDir(asset_manager, "images");
  //  const char* filename;
  //  while ((filename = AAssetDir_getNextFileName(assetDir)) != NULL)
  //  {
  //      Log("Debug: %s", filename);
  //  }
//
  //  AAssetDir_close(assetDir);

	#else
        Log("unknown target platform");

        DIR* DirHandle = NULL;
        dirent* FileHandle = NULL;

        // Needs improved
        if((DirHandle = opendir(Folder.c_str())) != NULL) {
            while((FileHandle = readdir(DirHandle)) != NULL) {
                if(std::string(FileHandle->d_name) == ".")  continue;
                if(std::string(FileHandle->d_name) == "..") continue;

                std::string Filename = Path + DIR_SEPARATOR + FileHandle->d_name;

                //Log("Found File: %s", Filename.c_str());

                List.push_back(Filename);
            }

            closedir(DirHandle);
        }else{
            Log("Unable to open directory : %s %s", Path.c_str(), strerror(errno));
        }

	#endif

	return List;
}

//-----------------------------------------------------------------------------
std::string FileManager::GetCWD() {
	std::string CWD;

	#ifdef __APPLE__
		NSString* ResourcePath = [[NSBundle mainBundle] resourcePath];
		CWD = [ResourcePath cStringUsingEncoding:1];
	#elif defined(_WIN32)
		char buffer[MAX_PATH];
		CWD = ((GetCurrentDirectory(MAX_PATH, buffer) > 0) ? std::string(buffer) : std::string(""));
    #elif __ANDROID__
        CWD = "./";

 //       const char* blah = SDL_GetBasePath();
 //   Log( "%s", blah);
 //   Log( "%s", SDL_GetBasePath());
   //     Log(SDL_GetPrefPath("My Company", "My Awesome SDL 2 Game"));

	#else
		char Buffer[MAXPATHLEN];
		CWD = (getcwd(Buffer, MAXPATHLEN) ? std::string(Buffer) : std::string(""));
	#endif

	return CWD;
}

//-----------------------------------------------------------------------------
std::string FileManager::GetFilenameWithoutExt(std::string Filename) {
	std::vector<std::string> Parts = Stringify::split(Filename, DIR_SEPARATOR);
	std::string NewFilename = Parts[Parts.size() - 1];

	// To Do: Filename could potentially have one or more dots
	Parts		= Stringify::split(NewFilename, ".");
	NewFilename	= Parts[0];

	return NewFilename;
}

//-----------------------------------------------------------------------------
std::string FileManager::GetFilenameExt(std::string Filename) 
{
	std::vector<std::string> Parts = Stringify::split(Filename, ".");

	return (Parts.size() <= 1 ? "" : Parts[Parts.size() - 1]);
}

#ifdef _WIN32
static int CALLBACK BrowseCallbackProc(HWND hwnd, UINT uMsg, LPARAM lParam, LPARAM lpData)
{

	if (uMsg == BFFM_INITIALIZED)
	{
		//std::string tmp = (const char *)lpData;
		//std::cout << "path: " << tmp << std::endl;
		//SendMessage(hwnd, BFFM_SETSELECTION, TRUE, lpData);
		LPCTSTR path = reinterpret_cast<LPCTSTR>(lpData);
		std::cout << "path: " << path << std::endl;
		::SendMessage(hwnd, BFFM_SETSELECTION, true, (LPARAM)path);
	}

	return 0;
}
#endif

//TODO test wether this also somehow leaks memory?
std::string FileManager::GetFolderPathFromDialog(std::string saved_path)
{
	std::string path;



#ifdef _WIN32
	//from https://stackoverflow.com/questions/12034943/win32-select-directory-dialog-from-c-c

	TCHAR tszPath[MAX_PATH];

	//TODO nextline
	LPCSTR initial_path_as_lpctstr = "F:\\Users\\rjv\\Documents\\Programming\\SDL\\vs_projects\\SDL2_Engine\\SDL2_Engine\\assets\\UserData\\Levels";

//std::string CWD = GetCWD();
//
//Log("CWD = %s", CWD.c_str());
////saved_path = CWD + DIR_SEPARATOR + saved_path;
//saved_path = CWD;
//Log("saved_path = %s", saved_path.c_str());


	//const char * path_param = saved_path.c_str();
	std::wstring wsaved_path(saved_path.begin(), saved_path.end());
	const wchar_t * path_param = wsaved_path.c_str();

	BROWSEINFO bi = { 0 };
	bi.lpszTitle = ("Browse for folder...");
	bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
	bi.lParam = reinterpret_cast<LPARAM>(initial_path_as_lpctstr);
	bi.lpfn = BrowseCallbackProc;
	//bi.lParam = (LPARAM)path_param;

	LPITEMIDLIST pidl = SHBrowseForFolder(&bi);

	if (pidl != 0)
	{
		//get the name of the folder and put it in path
		SHGetPathFromIDList(pidl, tszPath);

		//free memory used
		IMalloc * imalloc = 0;
		if (SUCCEEDED(SHGetMalloc(&imalloc)))
		{
			imalloc->Free(pidl);
			imalloc->Release();
		}

		path = tszPath;
			//return path;
	}
	else {
		path = "";
	}




#elif __ANDROID__
	//TODO make android
#endif


	// Now simply display path file name 

	Log("filepath: <%s>", path.c_str());
	return path;
}

//todo set allowed extentions in parameter...
//TODO somehow leaks memory?
std::string FileManager::GetFilePathFromDialog() 
{
	std::string filePath;

#ifdef _WIN32


	OPENFILENAME ofn;
	// a another memory buffer to contain the file name
	char szFile[100];

	ZeroMemory(&ofn, sizeof(ofn));
	GetOpenFileName(&ofn);

	//if (_tcslen(this->FileName) == 0) return false;
	//
	//return true;



	// open a file name
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = NULL;
	ofn.lpstrFile = szFile;
	ofn.lpstrFile[0] = '\0';
	ofn.nMaxFile = sizeof(szFile);
	ofn.lpstrFilter = "All\0*.*\0Text\0*.TXT\0";
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = NULL;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;


	GetOpenFileName(&ofn);

	filePath = ofn.lpstrFile;

#elif __ANDROID__
	//TODO make android
#endif

	// Now simply display the file name 
	Log("filepath: <%s>", filePath.c_str());

	return filePath;
}
//=============================================================================
