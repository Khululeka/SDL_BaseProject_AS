#ifndef __MATRIX3_H__
#define __MATRIX3_H__


#include "Vector2.h"

class Matrix3
{
public:
    double _00;
    double _01;
    double _02;

    double _10;
    double _11;
    double _12;

    double _20;
    double _21;
    double _22;

    Matrix3( );

	Matrix3(double _00, double _10, double _20,
				     double _01, double _11, double _21,
				     double _02, double _12, double _22);

	static Matrix3 translation(double x, double y);
	static Matrix3 scale(double x, double y);
	static Matrix3 rotation(double alpha);


	Vector2 multvec(Vector2 value);
	Matrix3 multmat(Matrix3 m);
	Matrix3 inverse();
	double cofactor(double m0, double m1, double m2, double m3);



};


#endif