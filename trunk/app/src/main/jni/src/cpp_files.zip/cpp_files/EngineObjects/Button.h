#pragma once


#include "../EngineObjects/Sprite.h"




class App;



class Button : public Sprite {

public:
//	Button();
	Button(Image* _image);
	//Button(Image* _image, std::string _text, TTF_Font* font, SDL_Color _textColor, SDL_Renderer* _renderer);
	Button(std::string _text, TTF_Font* font, SDL_Color _textColor, SDL_Renderer* _renderer);
	~Button();



	void setText(std::string text);

//	void set_OnLButtonUp_callback(std::function<void(void)> function);
	//void set_OnLButtonUp_callback(App* _callbackClass, void(App::*_function)(void));   /same but with functionpointer

protected:
	//void(App::*callback_OnLButtonUp)(void)  = NULL;
	//App* callbackClass = NULL;
};

