
#include "Animation.h"

Animation::Animation(std::string id, Sprite* sprite)
{
	mpSprite = sprite;
	mId = id;
}
//Animation::~Animation()
//{
//
//}
//
//
//
//void Animation::update() {
//
//}

void Animation::addSound(Sound* sound, bool loop)
{
	mpSound = sound;
	mLoopSound = loop;
	
}

void Animation::start()
{
	if (!mpSound) return;
	if (mLoopSound) {
		mpSound->start();
	}
	else {
		mpSound->play();
	}
}
void Animation::stop()
{
	if (!mpSound) return;
	//TODO perhaps enable fade-out or keep playing until end of sample.
	if (mLoopSound) {
		mpSound->stop();
	}
}