#include "nope.h"
#include "Helpers/Log.h"

#include "ManagersAndControllers/ImageBank.h"
#include "ManagersAndControllers/SoundBank.h"


#include "EngineObjects/Animation_Waggle.h"

#include <functional>

Nope::Nope() :
speed(1)
{
//	addState("default", { { ImageBank::Get("nope1"), ImageBank::Get("nope2"), ImageBank::Get("nope3") }, 150 }, NULL);
//	addState("walking", { { ImageBank::Get("nope1"), ImageBank::Get("nope2"), ImageBank::Get("nope3") }, 20 }, SoundBank::Get("nope"));
//	setState("default");


	//TODO probably better way to do this (
	//ANIM_IDLE
	//addAnimation({ { ImageBank::Get("nope1"), ImageBank::Get("nope2"), ImageBank::Get("nope3") }, 150 });
	//ANIM_WALKING
	//addAnimation({ { ImageBank::Get("nope1"), ImageBank::Get("nope2"), ImageBank::Get("nope3") }, 20 });

	animationList.resize(ANIM_TOTAL_ITEMS);
	//animationList[ANIM_IDLE] = { { ImageBank::Get("nope1"), ImageBank::Get("nope2"), ImageBank::Get("nope3") }, 150 };
	//animationList[ANIM_WALKING] = { { ImageBank::Get("nope1"), ImageBank::Get("nope2"), ImageBank::Get("nope3") }, 30 };
//	Animation* anim = new Animation_Sequence("walking", this, { ImageBank::Get("nope1"), ImageBank::Get("nope2"), ImageBank::Get("nope3") }, 150);

	Image* imgList[] = { ImageBank::Get("nope1"), ImageBank::Get("nope2"), ImageBank::Get("nope3") };
//	animationList[ANIM_IDLE] = std::make_unique<Animation_Sequence>("idle", this, imgList, 150 );
	animationList[ANIM_WALKING] = std::make_unique<Animation_Sequence>("walking", this, imgList, 30 );
	animationList[ANIM_WALKING].get()->addSound(SoundBank::Get("nope"), true);
	

	animationList[ANIM_IDLE] = std::make_unique<Animation_Waggle>("idle", this, 100, 0.2);

	soundList.resize(SOUND_TOTAL_ITEMS);
	soundList[SOUND_WALKING] = SoundBank::Get("nope");

	//curAnimation = animationList[ANIM_IDLE].get();
	startAnimation(ANIM_IDLE);
	setImage(ImageBank::Get("nope1"));

//	x = 0;
//	y = 0;
//
//	speed = 1;
}
Nope::~Nope() {
//	delete animationList[ANIM_IDLE];
//	delete animationList[ANIM_WALKING];
}
//--------------------------------------------------------------
void Nope::setup() {




}

//--------------------------------------------------------------
void Nope::update() {
	Sprite::update();

	moveLocalPosition(v);  //TODO sould probs be called "addLocalPosition"
	//if (moving) {
//	animate();
	//}

}

void Nope::setMovement(Vector2 movement) {
	v = movement.mult(speed);
	checkMoving();

    Log("bla %f",v.x);
    Log("bla %f",v.y);
}

void Nope::setMovement(double x, double y) {
	setMovement(Vector2(x, y));
}
//set movement to items' speed
void Nope::addMovement(Vector2 movement) {

//	Log("bla %f", movement.mult(speed).x);

//	Log("bla %f", v.x);

	v = v.add( movement.mult(speed) );


//	Log("bla %f",v.x);

	checkMoving();


}
void Nope::addMovement(double x, double y) {
    addMovement(Vector2(x, y));
}



void Nope::checkMoving() {
	if (v.y != 0 || v.x != 0) {
		if (!moving) {
			moving = true;
			startAnimation(ANIM_WALKING);
			//curAnimation = animationList[ANIM_WALKING].get();
			//soundList[SOUND_WALKING]->start();
		}
	}
	else {
		if (moving) {
			moving = false;
			stopAnimation();
			//curAnimation = animationList[ANIM_IDLE].get();
			//soundList[SOUND_WALKING]->stop();
		}
	}


}
