//==============================================================================
#include "Sound.h"

#include "../Helpers/Log.h"
//#include<iostream>

//==============================================================================
Sound::Sound() {
}

//------------------------------------------------------------------------------
Sound::~Sound() {
	if (SDLSound) {
		
		Mix_FreeChunk(SDLSound);
		SDLSound = NULL;
	}
}

//==============================================================================
bool Sound::Load(std::string Filename) {
	this->Filename = Filename;

	SDLSound = Mix_LoadWAV(Filename.c_str());
	if (SDLSound == NULL)
	{
		Log("Unable to load sound : %s : %s", Filename.c_str(), Mix_GetError());
		return false;
	}



	return true;
}


void Sound::play() {
	if (!SDLSound) { return; }
	Mix_PlayChannel(-1, SDLSound, 0);
}
void Sound::start() {
	if (!SDLSound) { return; }
	curChannel = Mix_PlayChannel(-1, SDLSound, -1);
}
void Sound::stop() {
	if (!SDLSound) { return; }
	Mix_HaltChannel(curChannel);
}