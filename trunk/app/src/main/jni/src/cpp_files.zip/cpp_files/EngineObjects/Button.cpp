#include "Button.h"

//#include "App.h"

#include "../Helpers/Log.h"
#include "../Globals.h"
//Button::Button() {
//
//}





Button::Button(Image* _image) {
	//Button();
	setImage(_image);
}
//Button::Button(Image* _image, std::string _text, TTF_Font* _font, SDL_Color _textColor, SDL_Renderer* _renderer) {
Button::Button(std::string _text, TTF_Font* _font, SDL_Color _textColor, SDL_Renderer* _renderer) 
{
		//	setImage(_image);

	setText(_text);
	//Texture* tx = new Texture();
	//if (!tx->loadFromRenderedText(_renderer, _text, _font, _textColor))
	//{
	//	printf("Failed to render text texture!\n");
	//}
	//
	//Image* img = new Image(_text, tx);
	//setImage(img);





//TODO when to call this? 	TTF_CloseFont(_font);


} 
Button::~Button()
{
	//each button creates its own Image with Texture, so have to be deleted here
	if (image) {
	//	if (image->tx)
			delete image->tx;
		delete image;
	}
}

//todo perhaps save texture for buttons that change tezt often, now slow.
void Button::setText(std::string text) {


	//todo make clear funct from here
	if (image) {
	//	if (image->tx)
			delete image->tx;
		delete image;
	}
	//todo make clear funct to here



	Texture* tx = new Texture();
	if (!tx->loadFromRenderedText(Globals::renderer, text, Globals::font, Globals::textColor))
	{
		printf("Failed to render text texture!\n");
	}
	Image* img = new Image(text, tx);
	setImage(img);

}


//void Button::setOnClick(std::function<void(void)> function) {
//	//set_OnLButtonUp_callback(function);
//	callback_OnLButtonUp = function;
//}
//void Button::set_OnLButtonUp_callback(std::function<void(void)> function) {
//	callback_OnLButtonUp = function;
//}

//void Button::set_OnLButtonUp_callback(App* _callbackClass, void(App::*function)(void)) {
//	callbackClass = _callbackClass;
//	callback_OnLButtonUp = function;
//}




//TODO add behaviour for mouseover / out / down / up

