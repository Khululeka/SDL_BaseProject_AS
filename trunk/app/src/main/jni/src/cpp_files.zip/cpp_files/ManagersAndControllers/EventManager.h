#ifndef _EventManager_H_
#define _EventManager_H_

#include <SDL.h>

class EventManager {

private:
	bool keys[300];  //262 TODO WHY doesnt this crash array out of range?
					//if on [1] get SDL_renderClear acces violation after pressing 's' and strange behaviour after pressing 'up' ......

public:
	EventManager();

	virtual ~EventManager();
	virtual void OnEvent(SDL_Event* Event);
	virtual void OnInputFocus();
	virtual void OnInputBlur();
	virtual void OnKeyDown(SDL_Keysym sym);
	virtual void OnKeyUp(SDL_Keysym sym);
	virtual void OnMouseFocus();
	virtual void OnMouseBlur();
	virtual void OnMouseMove(int x, int y, int relX, int relY, bool Left, bool Right, bool Middle);
	virtual void OnMouseWheel(int x, int y);    
	virtual void OnLButtonDown(int x, int y);
	virtual void OnLButtonUp(int x, int y);
	virtual void OnRButtonDown(int x, int y);
	virtual void OnRButtonUp(int x, int y);
	virtual void OnMButtonDown(int x, int y);
	virtual void OnMButtonUp(int x, int y);
	virtual void OnTouchDown(double x, double y);
	virtual void OnTouchUp(double x, double y);
	virtual void OnJoyAxis(Uint8 which, Uint8 axis, Sint16 value);
	virtual void OnJoyButtonDown(Uint8 which, Uint8 button);
	virtual void OnJoyButtonUp(Uint8 which, Uint8 button);
	virtual void OnJoyHat(Uint8 which, Uint8 hat, Uint8 value);
	virtual void OnJoyBall(Uint8 which, Uint8 ball, Sint16 xrel, Sint16 yrel);
	virtual void OnMinimize();
	virtual void OnRestore();
	virtual void OnResize(int w, int h);
	virtual void OnExpose();
	virtual void OnExit();
	virtual void OnUser(Uint8 type, int code, void* data1, void* data2);
};

#endif