//=============================================================================
#include "TextureBank.h"

#include "../App.h"
#include "FileManager.h"
#include "../Helpers/Log.h"

//=============================================================================
std::map<std::string, Texture*> TextureBank::TexList;

//=============================================================================
bool TextureBank::Init() {

	return loadFolder("assets/Textures");
}




//todo right now doesnt support spritesheets
//Should be called ONLY from imageBank!
bool TextureBank::loadFolder(std::string folder)
{
	Cleanup();

	SDL_Renderer* Renderer = App::getInstance()->getRenderer();
	if (!Renderer) return false;

	std::vector<std::string> Files = FileManager::GetFilesInFolder(folder); // Relative to CWD


	for (auto Filename : Files) {
		std::string Ext = FileManager::GetFilenameExt(Filename);
		std::string ID = FileManager::GetFilenameWithoutExt(Filename);

		// Skip all non-png files
		if (Ext != "png") continue;

		//Log("Add Texture : ID = %s : Filename = %s : Ext = %s", ID.c_str(), Filename.c_str(), Ext.c_str());
		AddTexture(Renderer, ID, Filename);
		//AddTexture(Renderer, "Test", "Textures/Test.png");

	}


	return true;

}




//-----------------------------------------------------------------------------
void TextureBank::Cleanup() {
	if(TexList.size() <= 0) return;

	for(auto& Iterator : TexList) {
		Texture* TheTexture = (Texture*)Iterator.second;

		if(TheTexture) {
			//TODO free first?
			delete TheTexture;
			TheTexture = NULL;
		}
	}

	TexList.clear();
}

//=============================================================================
void TextureBank::AddTexture(SDL_Renderer* Renderer, std::string ID, std::string Filename) {
    if(ID == "") return;

//TODO this is ugly
#ifdef __ANDROID__
    Filename = "Textures/" + Filename;
#endif

    Texture* NewTexture = new Texture();
    if(NewTexture->Load(Renderer, Filename) == false) {
		Log("Unable to Load Texture: %s", ID.c_str());
		return;
	}

    TexList[ID] = NewTexture;
}


//-----------------------------------------------------------------------------
Texture* TextureBank::Get(std::string ID) {
	if(TexList.find(ID) == TexList.end()) {
		Log("Warning: requested Texture ID <%s> not found.", ID.c_str());
		return 0;
	}

	return TexList[ID];
}

//=============================================================================
