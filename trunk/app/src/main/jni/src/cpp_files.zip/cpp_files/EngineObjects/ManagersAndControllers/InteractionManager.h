#pragma once

#include "../../ManagersAndControllers/EventManager.h"

#include "../Sprite.h"
#include "../Math/Vector2.h"



//struct SpriteState {
//	std::string name;
//	Animation animation;
//	Sound* sound;
////	Path path;
//};

#ifdef _WIN32
	#include <Windows.h>
#endif

//static class InteractionManager : public EventManager {
class InteractionManager : public EventManager {

public:

	InteractionManager();
	~InteractionManager();

	void addSprite(Sprite* _sprite);
	void removeSprite(Sprite* _sprite);

	void setMousePosition(Vector2 position);


	void update();


protected:
	bool hover;


	std::vector<Sprite*> spriteList;
	//Vector2 mousePosition;

	std::vector<Sprite*> getHitSprites(Vector2 position);

	#ifdef _WIN32
		HCURSOR  hCursorHand;
		HCURSOR  hCursorArrow;
	#endif

public:
	virtual void OnMouseMove(int x, int y, int relX, int relY, bool Left, bool Right, bool Middle);

	virtual void OnLButtonDown(int x, int y);
	virtual void OnLButtonUp(int x, int y);
	virtual void OnTouchDown(double x, double y);
	virtual void OnTouchUp(double x, double y);

};