#pragma once



#include "Animation.h"
#include "../ManagersAndControllers/Image.h"
#include <vector>


class Animation_Waggle : public Animation {

public:
	Animation_Waggle(std::string id, Sprite* sprite, int speed, double amplitude, int duration = 0);

	void update() override;


	void start() override;

private:
	int mSpeed = 0;//TODO could be in Animation
	double mAmplitude = 0;//TODO could be in Animation
	int mDuration = 0;//TODO could be in Animation
	int mCurTick = 0;//TODO could be in Animation

};