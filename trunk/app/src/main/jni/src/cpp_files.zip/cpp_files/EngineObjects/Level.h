#pragma once
#pragma once

#include "Container.h"
#include "Sprite.h"

/*
//TODO should this be composition?
A Container isn't truely a Transform, so no. A container should HAVE a Transform.
BUT i want to to things like container->setPosition() and container->setScale().
If Container HAS a Transform, I would have to redirect ALL of these kind of methods to the Transform!
If a Container IS a transform, I dont have to do anything, container->setPosition() automaticly calls Transform::setPosition() for the container object.

So logic says a ontainer should HAVE a Transform.
DRY/KISS/I just dont wat to have to write things like this for EVERY public transform method:
Container::setPosition(Vector2 position) {
mTransform.setPosition(Vector2 position);
}

*/
class Level
	: public Container
{

public:

	//	Container();
	void update();

private:
	std::vector<Sprite*> spriteList; //TODO make shared_ptrs (for all banks)

};
