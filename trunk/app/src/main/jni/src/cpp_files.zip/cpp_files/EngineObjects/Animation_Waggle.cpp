
#include "Animation_Waggle.h"
#include "Sprite.h"



//TODO add check for nullptrs (or make references???)
Animation_Waggle::Animation_Waggle(std::string id, Sprite* sprite, int speed, double amplitude, int duration)
	: Animation(id, sprite)
	, mSpeed(speed)
	, mAmplitude(amplitude)
	, mDuration(duration)
{
}






void Animation_Waggle::update()
{
//	mCurTick++;
//	if (curTick >= speed) {
//		curTick = 0;
//		if (curImageIndex >= images.size()) {
//			curImageIndex = 0;
//		}
//		curImage = images[curImageIndex];
//		mpSprite->setImage(curImage);
//	}


	mCurTick++;

	//sprite.rotation += this.amp * this.direction;
	if ((mCurTick % mSpeed) == 0) {
		if (mpSprite->getLocalRotation() == mAmplitude) {
			mpSprite->setLocalRotation(-mAmplitude);
		}
		else {
			mpSprite->setLocalRotation(mAmplitude);
		}
	}

	if (mDuration > 0 && mCurTick >= mDuration) {
		mpSprite->stopAnimation();
		mpSprite->setLocalRotation(0);

	}


}


void Animation_Waggle::start()
{
	Animation::start();
	mCurTick = 0;
	mpSprite->setLocalRotation(mAmplitude);//TODO make relative to starting rotation (ow only OK with startin grotarion = 0)
}