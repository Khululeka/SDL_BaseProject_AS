#pragma once


#include "../EngineObjects/Sprite.h"


class IE_Corner : public Sprite {

public:
	IE_Corner();
	IE_Corner(int x, int y);

};


class IE_Line : public BasicSprite {

public:
	IE_Line();

	void setPositions(Vector2 start, Vector2 end);
};