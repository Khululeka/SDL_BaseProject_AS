#pragma once

class Sprite;
#include "../ManagersAndControllers/Sound.h"


class Animation {

public:
	Animation(std::string id, Sprite* sprite);
	virtual ~Animation() {}
	virtual void update()=0;

	void addSound(Sound* sound, bool loop);
	virtual void start();
	virtual void stop();

protected:
	Sprite* mpSprite;
	Sound* mpSound;
	bool mLoopSound;
	std::string mId;
	

};