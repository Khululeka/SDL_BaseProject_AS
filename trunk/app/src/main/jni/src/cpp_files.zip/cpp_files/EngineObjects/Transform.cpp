/*
    // transforms a point from local coordinates to world coordinates
	-->pointLocalToWorld

    // transforms a point from world coordinates to local coordinates
	--> pointWorldToLocal

    // transforms a point from @param<Transform> coordinates to local coordinates
	--> pointTransToLocal

    // sets the position relative to the parent
	--> setLocalPosition

    // moves the position relative to the current poristion relative to the parent
	--> moveLocalPosition

*/


#include "Transform.h"

#include <algorithm>

#include "../Helpers/Log.h"

Transform::Transform() :
	parent(NULL)
{
	
}

Transform::~Transform() {
        //TODO clear arrays / pointers;

	//remove this from any children
	for (auto child : children) {
		child->parent = NULL;
		child->setDirty();
	}

	// remove this from the current parent
	if (parent) {
		parent->children.erase(std::remove(parent->children.begin(), parent->children.end(), this), parent->children.end());
	}
}


/*
* Whenever any change happens that changes the localToWorldMatrix
* this should be called. That way the next time localToWorldMatrix
* is requested it will be recalculated
*/
void Transform::setDirty()
{
    // only update dirty boolean if it isn't already dirty
    if (!isDirty) {
        isDirty = true;
        isInverseDirty = true;

        // set all children to be dirty since any modification
        // of a parent transform also effects its children's
        // localToWorldTransform
        if (children.size() > 0) {
            for (auto &child : children)  {
                child->setDirty();
            }
        }
    }
}

    // change the parent transform.
    // setting it to NULL makes the
    // transform a child of world coordinates
void Transform::setParent(Transform* value) {
            // remove this from the previous parent
            if (parent) {
                parent->children.erase(std::remove(parent->children.begin(), parent->children.end(), this), parent->children.end());
            }

            // assign new parent
            parent = value;
            if (parent) {
                parent->children.push_back(this); 
            }
            setDirty();
    }

Transform* Transform::getParent() {
            return parent;
    }

    // calculates the transform matrix that converts
    // from local coordinates to the coordinate space
    // of the parent transform
Matrix3 Transform::calculateLocalToParentMatrix() {
    //    return Matrix3::translation(localPosition.x, localPosition.y).multmat(
	//		   Matrix3::rotation(localRotation) ).multmat( 
	//		   Matrix3::scale(localScale.x, localScale.y));
 

			return  Matrix3::scale(localScale.x, localScale.y).multmat(
					Matrix3::translation(localPosition.x, localPosition.y).multmat(
					Matrix3::rotation(localRotation))
					);
    }



//TODO probably move calc functions back into calling function..


void Transform::calcLocalToWorld() {
	if (isDirty) {
		if (parent == NULL) {
			// if the parent is NULL then the parent is
			// the world so the localToWorldMatrix
			// is the same as local to parent matrix
			localToWorldMatrix = calculateLocalToParentMatrix();
		}
		else {
			// if there is a parent, then the localToWorldMatrix
			// is calcualted recursively using the parent's localToWorldMatrix
			// concatenated with the local to parent matrix
			localToWorldMatrix = parent->getLocalToWorldMatrix().multmat(calculateLocalToParentMatrix());
		}

		isDirty = false;
	}
}
void Transform::calcWorldToLocal() {
	if (isInverseDirty) {
		// the worldToLocalMatrix is the inverse of the localToWorldMatrix
		worldToLocalMatrix = getLocalToWorldMatrix().inverse();
		isInverseDirty = false;
	}
}


    // gets the matrix that converts from local
    // coordinates to world coordinates
Matrix3 Transform::getLocalToWorldMatrix(){
	calcLocalToWorld();
    return localToWorldMatrix;
}

Matrix3 Transform::getWorldToLocalMatrix() {
	calcWorldToLocal();
	return worldToLocalMatrix;
 }

    // transforms a point from local coordinates to world coordinates
//TODO doesnt work well when rotated(?)
Vector2 Transform::pointLocalToWorld(Vector2 point) {
	return getLocalToWorldMatrix().multvec( point );
} 
Vector2 Transform::pointLocalToWorld(double x, double y) {
	return pointLocalToWorld(Vector2(x, y));
}

    // transforms a point from world coordinates to local coordinates
Vector2 Transform::pointWorldToLocal(Vector2 point) {
            return getWorldToLocalMatrix().multvec(point);
} 
Vector2 Transform::pointWorldToLocal(double x, double y) {
            return getWorldToLocalMatrix().multvec( Vector2(x, y) );
}

    // transforms a point from @param<Transform> coordinates to local coordinates
Vector2 Transform::pointTransToLocal(Vector2 point, Transform* trans) {
            return getWorldToLocalMatrix().multvec(trans->pointLocalToWorld(point));
}
Vector2 Transform::pointTransToLocal(double x, double y, Transform* trans) {
            return getWorldToLocalMatrix().multvec(trans->pointLocalToWorld( Vector2(x, y) ));
}

// transforms a point from @param<Transform> coordinates to local coordinates
Vector2 Transform::pointLocalToTrans(Vector2 point, Transform* trans) {
	return getLocalToWorldMatrix().multvec(trans->pointLocalToWorld(point));
}
Vector2 Transform::pointLocalToTrans(double x, double y, Transform* trans) {
	return getLocalToWorldMatrix().multvec(trans->pointLocalToWorld(Vector2(x, y)));
}


//TODO maak werkend
// transforms a direction from local coordinates to world coordinates
Vector2 Transform::transformDirection(Vector2 point) {
    // matrix multiply padding the extra element with a 0
    // notice that the worldToLocalMatrix is used here
    // and the point is multiplied as a row matrix before the
    // transform matrix. This is the proper way to transform
    // directions as described before in this article

    // Matrix3x1 transformResult = Matrix3x1(point.x, point.y, 0) * getWorldToLocalMatrix();
    // return new Vector2(transformResult[1,1], transformResult[2,1], transformResult[3,1]);
    return getWorldToLocalMatrix().multvec(point);  //todo moet andersom? vec*mat
}

//TODO maak werkend
// transforms a direction from world coordinates to local coordinates
Vector2 Transform::inverseTransformDirection(Vector2 point) {
    // same logic as transformDirection only with the inverse of the
    // inverse localToWorldMatrix which is just the localToWorldMatrix

    // Matrix3x1 transformResult = Matrix3x1(point.x, point.y, 0) * getLocalToWorldMatrix();
    // return new Vector2(transformResult[1,1], transformResult[2,1], transformResult[3,1]);
    return getLocalToWorldMatrix().multvec(point);  //todo moet andersom? vec*mat
}


Vector2 Transform::getLocalPosition() {
    return localPosition;
}
Vector2 Transform::getGlobalPosition() {
	return pointLocalToWorld(0, 0);
//	return getLocalToWorldMatrix().multvec( Vector2(1,1) );
}
Vector2 Transform::getRelativePosition(Transform* trans) {
	return pointLocalToTrans(0, 0, trans);
	//	return getLocalToWorldMatrix().multvec( Vector2(1,1) );
}

    // sets the position relative to the parent
void Transform::setLocalPosition(Vector2 value) {
    setDirty();
    localPosition = value;
} 
void Transform::setLocalPosition(double x, double y) {
    setDirty();
    localPosition = Vector2(x, y);
}

// moves the position relative to the current position
void Transform::moveLocalPosition(Vector2 value) {
    setLocalPosition( localPosition.add(value) );
} 
void Transform::moveLocalPosition(double x, double y) {
    setLocalPosition( localPosition.add(x, y) );
}

//TODO IMPLEMENT now sets localPosition
// sets the position relative to the stage
void Transform::setGlobalPosition(Vector2 value) {
	setDirty();
	if (parent) {
		localPosition = parent->pointWorldToLocal(value);
	} else {
		localPosition = value;
	}
}
void Transform::setGlobalPosition(double x, double y) {
	setGlobalPosition( Vector2(x, y) );
}

//// moves the position relative to the current position
//void Transform::moveGlobalPosition(Vector2 value) {
//	setGlobalPosition(getGlobalPosition.add(value));
//}
//void Transform::moveGlobalPosition(double x, double y) {
//	setGlobalPosition(localPosition.add(x, y));
//}

//TODO perhaps setGlobalPosition etc?


void Transform::setLocalRotation(double value) {
    setDirty();
    localRotation = value;
}
void Transform::addLocalRotation(double value) {
	setDirty();
	localRotation += value;
}
double Transform::getLocalRotation() {
    return localRotation;
}
double Transform::getGlobalRotation() {
	if (parent == NULL) {
		return localRotation;
	}
	else {
		return (parent->getGlobalRotation() + localRotation);
	}
}
//TODO make
double Transform::getRelativeRotation(Transform* trans) {
	return localRotation;
}


void Transform::setLocalScale(Vector2 value) {
    setDirty();
    localScale = value;
}

void Transform::setLocalScale(double x, double y) {
	setLocalScale( Vector2(x, y) ); 
}

void Transform::setLocalScale(double xy) {
	setLocalScale( Vector2(xy, xy) );
}

Vector2 Transform::getLocalScale() {
	return localScale;
}
Vector2 Transform::getGlobalScale() {
	if (parent) {
		return (parent->getGlobalScale().add(localScale.sub(Vector2(1, 1))));
	} else {
		return localScale;
	}
}

//TODO make
Vector2 Transform::getRelativeScale(Transform* trans) {
	return localScale;
}










