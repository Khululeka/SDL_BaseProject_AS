#include "CollisionManager.h"

//#include "../../Helpers/Log.h"
//#include "../Sprite.h"
//#include <vector>

CollisionManager::CollisionManager() { }

CollisionManager::~CollisionManager() { }

bool CollisionManager::pointVsRect(Vector2 point, SDL_Rect rect) {
	if (point.x < rect.x		 ) return false;
	if (point.x > rect.x + rect.w) return false;
	if (point.y < rect.y		 ) return false;
	if (point.y > rect.y + rect.h) return false;
	return true;
}