//==============================================================================
#include "Music.h"


#include "../Helpers/Log.h"
//#include<iostream>

//==============================================================================
Music::Music() {
}

//------------------------------------------------------------------------------
Music::~Music() {
	if (SDLMusic) {

		Mix_FreeMusic(SDLMusic);
		SDLMusic = NULL;
	}
}

//==============================================================================
bool Music::Load(std::string Filename) {
	this->Filename = Filename;

	SDLMusic = Mix_LoadMUS(Filename.c_str());
	if (SDLMusic == NULL)
	{
		Log("Unable to load music : %s : %s", Filename.c_str(), Mix_GetError());
		return false;
	}



	return true;
}


void Music::play() {
	Mix_PlayMusic(SDLMusic, -1);
}