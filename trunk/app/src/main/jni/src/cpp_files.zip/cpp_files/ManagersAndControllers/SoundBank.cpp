//=============================================================================
#include "SoundBank.h"

#include "../App.h"
#include "FileManager.h"
#include "../Helpers/Log.h"

//=============================================================================
std::map<std::string, Sound*> SoundBank::SoundList;
std::map<std::string, Music*> SoundBank::MusicList;

//=============================================================================
bool SoundBank::Init() {
	Cleanup();

	SDL_Renderer* Renderer = App::getInstance()->getRenderer();
	if(!Renderer) return false;

	std::vector<std::string> SoundFiles = FileManager::GetFilesInFolder("assets/Sounds"); // Relative to CWD
	std::vector<std::string> MusicFiles = FileManager::GetFilesInFolder("assets/Music"); // Relative to CWD


	for(auto Filename : SoundFiles) {
        std::string Ext = FileManager::GetFilenameExt(Filename);
		std::string ID  = FileManager::GetFilenameWithoutExt(Filename);
        if(Ext != "wav") continue;
		//Log("Add Sound : ID = %s : Filename = %s : Ext = %s", ID.c_str(), Filename.c_str(), Ext.c_str());
		AddSound(ID, Filename);
	}
	for (auto Filename : MusicFiles) {
		std::string Ext = FileManager::GetFilenameExt(Filename);
		std::string ID = FileManager::GetFilenameWithoutExt(Filename);
		if (Ext != "wav") continue;
		//Log("Add Music : ID = %s : Filename = %s : Ext = %s", ID.c_str(), Filename.c_str(), Ext.c_str());
		AddMusic(ID, Filename);
	}



	return true;
}

//-----------------------------------------------------------------------------
void SoundBank::Cleanup() {
	if(SoundList.size() <= 0) return;
	for(auto& Iterator : SoundList) {
		Sound* TheSound = (Sound*)Iterator.second;
		if(TheSound) {
			//TODO free first?
			delete TheSound;
			TheSound = NULL;
		}
	}
	SoundList.clear();

	if (MusicList.size() <= 0) return;
	for (auto& Iterator : MusicList) {
		Music* TheMusic = (Music*)Iterator.second;
		if (TheMusic) {
			//TODO free first?
			delete TheMusic;
			TheMusic = NULL;
		}
	}
	MusicList.clear();
}

//=============================================================================
void SoundBank::AddSound( std::string ID, std::string Filename) {
    if(ID == "") return;


//TODO this is ugly
#ifdef __ANDROID__
    Filename = "Sounds/" + Filename;
#endif

    Sound* NewSound = new Sound();
    if(NewSound->Load(Filename) == false) {
		Log("Unable to Load Sound: %s", ID.c_str());
		return;
	}

    SoundList[ID] = NewSound;
}

//=============================================================================
void SoundBank::AddMusic(std::string ID, std::string Filename) {
	if (ID == "") return;


//TODO this is ugly
#ifdef __ANDROID__
    Filename = "Music/" + Filename;
#endif

	Music* NewMusic = new Music();
	if (NewMusic->Load(Filename) == false) {
		Log("Unable to Load Music: %s", ID.c_str());
		return;
	}

	MusicList[ID] = NewMusic;
}

//-----------------------------------------------------------------------------
Sound* SoundBank::Get(std::string ID) {
	if (SoundList.find(ID) == SoundList.end()) {
		Log("Warning: requested Sound ID <%s> not found.", ID.c_str());
		return 0;
	}
	return SoundList[ID];
}

//-----------------------------------------------------------------------------
Music* SoundBank::GetMusic(std::string ID) {
	if (MusicList.find(ID) == MusicList.end()) {
		Log("Warning: requested Music ID <%s> not found.", ID.c_str());
		return 0;
	}
	
	return MusicList[ID];
}

void SoundBank::toggleMusic() {
	//If the music is paused
	if (Mix_PausedMusic() == 1)
	{
		//Resume the music
		Mix_ResumeMusic();
	}
	//If the music is playing
	else
	{
		//Pause the music
		Mix_PauseMusic();
	}
}
//=============================================================================
