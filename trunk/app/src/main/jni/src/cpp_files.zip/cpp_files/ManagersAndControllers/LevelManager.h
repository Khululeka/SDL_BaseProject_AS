#pragma once


#include "../EngineObjects/BasicSprite.h"
#include <map>


//static enum objectProperties {
enum objectProperties {
	LEVEL_MANAGER_OBJECT_PROPERTIES_UNDEFINED,
	LEVEL_MANAGER_OBJECT_PROPERTIES_TYPE,
	LEVEL_MANAGER_OBJECT_PROPERTIES_X,
	LEVEL_MANAGER_OBJECT_PROPERTIES_Y,
	LEVEL_MANAGER_OBJECT_PROPERTIES_ANIMATIONS,
};

//TODO use defines (search this)


class LevelManager {
public:
	//	LevelManager();
	//	~LevelManager();


//	static Container openLevel(int level);
	static std::unique_ptr<Container> openLevel(int level);
	//static void saveLevel(int level, std::vector<BasicSprite> characters);
	static void saveLevel(int level, Container characters);


private:

	static std::map<std::string, objectProperties> s_mapObjectProperties;
	static void initMap();
};