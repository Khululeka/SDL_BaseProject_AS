//==============================================================================
/*
	Primary application class

	3/11/2014
	SDLTutorials.com
	Tim Jones




	Main TODO list:
	--> make bettter (and definate) folder structure
	--> Make is easyer to path #includes in Android Studio
	--> link assets in Android studio to main assets folder









*/
//==============================================================================
#pragma once


#include <SDL.h>
#include "ManagersAndControllers/EventManager.h"
#include "EngineObjects/ManagersAndControllers/InteractionManager.h"
#include "Editors/ImageEditor.h"
#include "EngineObjects/Button.h"
//#include "EngineObjects/Sprite.h"
#include "nope.h"








class App : public EventManager {  //TODO why public?
	protected:
		static App Instance;
	//	EventManager eventMan;  //TODO should be static?  getting unresolved externals

		bool running = true;
		bool editingMode = false;

		SDL_Window* window = NULL;
		SDL_Renderer* renderer = NULL;
		SDL_Surface* primarySurface = NULL;

		static const int windowWidth = 1024;
		static const int windowHeight = 768;

		int actualWindowWidth;
		int actualWindowHeight;

        int testInt;

		ImageEditor* imageEditor = NULL;
		InteractionManager interactionManager;

	protected:
		App();

		//Button* button1;
		std::shared_ptr<Button> button1;
		
		std::vector<Sprite*> interactiveSprites;//TODO make deletes in destructor / cleanup
		std::vector<BasicSprite*> sprites;//TODO make deletes in destructor / cleanup

		void btnOpenLevel1_onClick();
		void btnOpenLevel2_onClick();
		void btnOpenLevel3_onClick();
		void openLevel();
		void openLevel(int level);

		Container* levelContainer; //TODO should be pntr?
		std::unique_ptr<Container> pLevelContainer; //TODO should be pntr?
		Container* UI;
		void initContainers();
		void resetContainers();

		Nope* nope;
		BasicSprite nope2;
		BasicSprite nope3;
		Transform camera;

		// Capture SDL Events
		//void OnEvent(SDL_Event* Event);
		//void OnEvent(SDL_Event Event);

		bool init();
		void loop();
		void render();
		void cleanup();

		//std::function<void(void)> button1Pressed();
		void buttonEditor_onClick();
//		void button1Pressed2();


		void character_onClick(Sprite* sprite);
		void character_onClick2();

		BasicSprite* controllingSprite = NULL;

	public:
		int execute(int argc, char* argv[]);

	public:
		SDL_Renderer* getRenderer();
		SDL_Surface* getPrimarySurface();
		InteractionManager* getInteractionManager();

	public:
		static App* getInstance();

		static int GetWindowWidth();
		static int GetWindowHeight();

		void OnExit();  //TOSO static??	
		
		virtual void OnKeyDown(SDL_Keysym sym);
		virtual void OnKeyUp(SDL_Keysym sym);


		virtual void OnLButtonDown(int x, int y);
		virtual void OnRButtonDown(int x, int y);
		virtual void OnLButtonUp(int x, int y);
		virtual void OnTouchDown(double x, double y);
		virtual void OnTouchUp(double x, double y);


		virtual void OnMouseWheel(int x, int y);
};

