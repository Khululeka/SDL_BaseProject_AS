
#include "Animation_Sequence.h"
#include "Sprite.h"

Animation_Sequence::Animation_Sequence(std::string id, Sprite* sprite, Image* _images[], int _speed)
	: Animation(id, sprite)
	, speed(_speed)
//	, images(_images, _images + sizeof(_images) / sizeof(_images[0]))  //TODO what does the bit after the coma do?
																	 //https://stackoverflow.com/questions/2236197/what-is-the-easiest-way-to-initialize-a-stdvector-with-hardcoded-elements
																	 //	
																	 //sizeof(array) is one of the few exceptions that allows to get the total size of elements of the array and NOT the arr pointer dimension.So basically he's using vector(pointer_to_first_element, pointer_to_first_element + size_in_bytes_of_the_whole_array / size_of_one_element) that is: vector(pointer_to_first_element, pointer_after_final_element). The type is already given with the <int>, so the vector knows how much is one element. Remember that iterators can be treated as pointers so you're basically using the vector(iterator begin, iterator end) constructor ? Johnny Pauling Aug 17 '12 at 12:58
{

	for (int iImage = 0; iImage < sizeof(_images)-1; iImage++) {
		images.push_back(_images[iImage]);
	}
}

//TODO add check for nullptrs (or make references???)
Animation_Sequence::Animation_Sequence(std::string id, Sprite* sprite, std::vector<Image*> _images, int _speed)
	: Animation(id, sprite)
	, speed(_speed)
	, images(_images)
	, curImage(_images[0])
{
}






void Animation_Sequence::update() 
{
	curTick++;
	if (curTick >= speed) {
		curTick = 0;
		curImageIndex++;
		if (curImageIndex >= images.size()) {
			curImageIndex = 0;
		}
		curImage = images[curImageIndex];
		mpSprite->setImage(curImage);
	}
}


void Animation_Sequence::start()
{
	Animation::start();
	curTick = 0;//TODO could be in Animation
	curImageIndex = 0;
}