/*

//==============================================================================
#include "App_Nopes.h"
#include "Helpers/Log.h"


//App_Nopes App_Nopes::Instance;

//App_Nopes* App_Nopes::GetInstance() { return &App_Nopes::Instance; }


void App_Nopes::Render() {
	SDL_RenderClear(Renderer);

	//	if (TextureBank::Get("Test")) {
	//		TextureBank::Get("Test")->Render(0, 0); // You should really check your pointers
	//	}
	//nope->TxId = "Test";
	//	nope->render(&camera);
	//	nope2.render(&camera);
	//	nope3.render(&camera);
	Log("dsada");
		nope->render();
		nope2.render();
		nope3.render();

	SDL_RenderPresent(Renderer);
}


////------------------------------------------------------------------------------
//int App_Nopes::Execute(int argc, char* argv[]) {
//
//	Log("blabla");
//
//	if (!Init()) return 0;
//
//	SDL_Event Event;
//
//	while (Running) {
//		while (SDL_PollEvent(&Event) != 0) {
//			OnEvent(&Event);
//		}
//	
//		Loop();
//		Render();
//
//		SDL_Delay(1); // Breath
//	}
//
//	Cleanup();
//
//	return 1;
//}




*/

