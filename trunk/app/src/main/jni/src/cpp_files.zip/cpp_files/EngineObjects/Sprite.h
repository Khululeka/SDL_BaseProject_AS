#pragma once



#include "BasicSprite.h"

#include <functional>

#include "../ManagersAndControllers/Sound.h"
#include "Animation.h"


//#include <iterator>
#include <map>
//TODO this also interacts when it is not being rendered (not in a stage like container) do something about that


class Sprite : public BasicSprite {

public:

	Sprite();
//	using BasicSprite::Sprite;// (Image* img);
	Sprite(Image* img);
	~Sprite() override;

	void update() override;

	void setInteractive(bool value);

	//void update();

	//moved to interactionmanager void setInteractive(bool val);
	SDL_Rect getHitzoneRect();


	//*****************************************
	//*************for interaction*************
	//*****************************************
	bool isClickThrouhable = false;
	void setOnClick(std::function<void(void)> function); //todo make synoniem
	void setOnClick_returnSelf(std::function<void(Sprite*)> function); //todo make synoniem
//	void OnLButtonUp(int x, int y);

	void setDraggable(bool value);

	bool draggable = false;
	bool draggable2 = false; //TODO delete
	bool isDragging();

	//*****************************************
	//*****************for animation***********
	//*****************************************
//	void addState(std::string _name, Animation _animation, Sound* _sound);
//	void setState(std::string stateName);

//	void addAnimation(Animation _animation);
//	void setAnimation(Animation _animation);

	//*****************************************
	//*****************for animation***********
	//*****************************************
	//	std::map<std::string, SpriteState> stateList;  //static TODO ?  //TODO enums instead of stringMap?
	//	SpriteState* curState = NULL;

	//TODO refactor ALL to either list or map
	std::vector< std::unique_ptr<Animation> > animationList;
	std::map< std::string, std::unique_ptr<Animation> > animationMap;

	Animation* curAnimation = NULL;
	//std::vector< std::unique_ptr<Sound> > soundList; //TODO should anumaton also contain a sound?
	std::vector<Sound*> soundList; //TODO make shared_ptrs (for all banks)
	//TODO should anumaton also contain a sound?


	void startAnimation(int id);
	void startAnimation(std::string id);
	void stopAnimation();

protected:
	std::function<void(void)> callback_OnLButtonUp = NULL;
	std::function<void(Sprite*)> callback_OnLButtonUp_returnSelf = NULL;
//	bool callback_returnSelf = false;

	bool mIsInteractive = false;
	bool dragging = false;
	Vector2 draggingOffset;





public:
	virtual void OnMouseMove(int x, int y, int relX, int relY, bool Left, bool Right, bool Middle);
	virtual void OnLButtonDown(int x, int y);
	virtual void OnLButtonUp(int x, int y);
	virtual void OnTouchDown(double x, double y);
	virtual void OnTouchUp(double x, double y);

};





//struct SpriteState {
//	std::string name;
//	Animation animation;
//	Sound* sound;
////	Path path;
//};