//=============================================================================
#include "ImageBank.h"

#include "../App.h"
#include "FileManager.h"
#include "../Helpers/Log.h"


#include <algorithm> 
#include <iterator>
#include <iostream>

#include "jsoncpp/json/json.h"


#include "TextureBank.h"
//#include <fstream>


//=============================================================================
std::map<std::string, Image*> ImageBank::ImgList;

//=============================================================================
bool ImageBank::Init() {
	return loadFolder("assets/Textures");
}



std::vector<Image*>  ImageBank::getImageList()
{
	std::vector<Image*> returnList;
	for (auto const& x : ImgList) {
		returnList.push_back(x.second);
	}
	return returnList;
}



//todo right now doesnt support spritesheets
bool ImageBank::loadFolder(std::string folder)
{
	TextureBank::loadFolder(folder);

	Cleanup();

	SDL_Renderer* Renderer = App::getInstance()->getRenderer();
	if (!Renderer) return false;

	std::vector<std::string> Files = FileManager::GetFilesInFolder(folder); // Relative to CWD


	for (auto Filename : Files) {
		std::string Ext = FileManager::GetFilenameExt(Filename);
		std::string txId = FileManager::GetFilenameWithoutExt(Filename);

		// Skip all non-png files
		if (Ext != "json") { continue; }
		//JSON file found, name will be the same as txId.
		//All images on the texture will have a configred rect in the JSON.

		Texture* tx = TextureBank::Get(txId);

		if (tx == NULL) {
			Log("WARNING :found json file with no same named texture (PNG) file. Initiated ImageBank before TextureBank?")
				continue;
		}

		std::string jsonPath = "assets/Textures/" + txId + "." + Ext;
		//	std::ifstream fileStream = std::ifstream(jsonPath, std::ifstream::binary);

		//std::ifstream fileStream = FileManager::GetContentsStream(jsonPath);

		char* file_contents = FileManager::file_read(jsonPath);
		//	Log(file_contents);  //TODO this makes unrecugnisable compile error in AS.

		//    Log("JSON file: \n %s", file_contents);

		//	std::cout << file_contents;
		Json::Reader reader;
		Json::Value root;


		bool parsingSuccessful = reader.parse(file_contents, root, false);

		//	bool parsingSuccessful = reader.parse(fileStream, root, false);
		if (!parsingSuccessful)
		{
			Log("Failed to parse JSON file: <%s> Error: <%s>", jsonPath.c_str(), reader.getFormatedErrorMessages().c_str());
		}



		//	std::cout << root;


		const Json::Value frames = root["frames"];



		for (unsigned i = 0; i < frames.size(); ++i)
		{
			std::string ImageId = FileManager::GetFilenameWithoutExt(frames[i]["filename"].asString());
			SDL_Rect rect = SDL_Rect{ frames[i]["frame"]["x"].asInt(),
				frames[i]["frame"]["y"].asInt(),
				frames[i]["frame"]["w"].asInt(),
				frames[i]["frame"]["h"].asInt() };

			AddImage(ImageId, tx, rect);
		}
	}




	//find all textures that dont have a JSON to ceate images
	//Create one image from each one (texture file should be just 1 image, not a spritesheet)
	std::vector<std::string> sl_JSONs;
	std::vector<std::string> sl_PNGs;
	for (auto Filename : Files) {
		std::string ext = FileManager::GetFilenameExt(Filename);
		std::string name = FileManager::GetFilenameWithoutExt(Filename);

		if (ext != "json") { sl_JSONs.push_back(name); }
		if (ext != "png") { sl_PNGs.push_back(name); }

	}
	std::sort(sl_JSONs.begin(), sl_JSONs.end());
	std::sort(sl_PNGs.begin(), sl_PNGs.end());
	std::vector<std::string> sl_diff;
	std::set_difference(sl_JSONs.begin(), sl_JSONs.end(), sl_PNGs.begin(), sl_PNGs.end(), std::back_inserter(sl_diff));

	//	Log("sl_JSONs");
	//	for (auto i : sl_JSONs)
	//		//std::cout << i << ' ';
	//		Log(i.c_str());
	//	Log("sl_PNGs");
	//	for (auto i : sl_PNGs)
	//		//std::cout << i << ' ';
	//		Log(i.c_str());
	//	
	//	Log("sl_diff");
	//	for (auto i : sl_diff)
	//		//std::cout << i << ' ';
	//		Log(i.c_str());

	for (auto ImageId : sl_diff) {
		Texture* tx = TextureBank::Get(ImageId);
		SDL_Rect totalTx = { 0, 0, tx->Width, tx->Height };
		AddImage(ImageId, tx, totalTx);
	}

	return true;

}
//-----------------------------------------------------------------------------
void ImageBank::Cleanup() 
{
	if(ImgList.size() <= 0) return;

	for(auto& Iterator : ImgList) {
		Image* TheImage = (Image*)Iterator.second;

		if(TheImage) {
			delete TheImage;
			TheImage = NULL;
		}
	}

	ImgList.clear();
}

//=============================================================================
void ImageBank::AddImage(std::string ID, Texture* tx,  SDL_Rect rect) {
    if(ID == "") return;


    Image* NewImage = new Image(ID, tx, rect);
    if(NewImage == NULL) {
		Log("Unable to create Image: %s", ID.c_str());
		return;
	}

	//Log("Added Image : ID = %s ", ID.c_str());
    ImgList[ID] = NewImage;
}

//-----------------------------------------------------------------------------
Image* ImageBank::Get(std::string ID) {
	if(ImgList.size() <= 0) return 0;		//TODO make all BANKS DRY
	if(ImgList.find(ID) == ImgList.end()) {
		Log("Warning: requested Image ID <%s> not found.", ID.c_str());
		return 0;
	}


	return ImgList[ID];
}

//=============================================================================
