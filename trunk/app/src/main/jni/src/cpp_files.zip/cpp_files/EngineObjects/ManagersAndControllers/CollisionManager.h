#pragma once


#include "../Math/Vector2.h"
#include <SDL.h>




class CollisionManager {

public:

	CollisionManager();
	~CollisionManager();


	static bool pointVsRect(Vector2 point, SDL_Rect rect);

protected:
};