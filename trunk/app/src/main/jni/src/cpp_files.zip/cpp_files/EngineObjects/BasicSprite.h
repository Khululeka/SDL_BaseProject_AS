#pragma once

#include "Container.h"
#include "../ManagersAndControllers/Image.h"
#include "../EngineObjects/Math/Vector2.h"


class BasicSprite : public Container {

public:

	BasicSprite();
	BasicSprite(Image* img);  //TODO needed? or how t oremove default..
	~BasicSprite() override;
	void deleteImageAndTexture();

	void render() override;
	void render(Transform* camera);

	void setImage(Image* image);

	void setLocalScale(Vector2 vec) override;
	void setLocalScale(double x, double y) override;
	void setLocalScale(double xy) override;

	std::string getID();

//	Matrix3 getLocalToWorldMatrix();
//	Matrix3 getWorldToLocalMatrix();

protected:
	Image* image; 
	int width;
	int height;
	//TODO overwrite setLocal/Glabal scale from transform and make image.scage same as global scale (image w and h accordingly)


	//overrides from TRANSFORM
	//precalculate for rendering
	Vector2 globalPosition = Vector2();
	double globalRotation = 0;
	Vector2 globalScale = Vector2(1, 1);
};



