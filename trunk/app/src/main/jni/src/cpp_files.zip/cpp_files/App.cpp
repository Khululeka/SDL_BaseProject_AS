//==============================================================================
#include "App.h"
#include "Helpers/Log.h"

#include <functional>
#include <iostream>

#include "Globals.h"


#include <SDL_image.h>


#include "ManagersAndControllers/TextureBank.h"
#include "ManagersAndControllers/ImageBank.h"
#include "ManagersAndControllers/SoundBank.h"

#include "ManagersAndControllers/LevelManager.h"

App App::Instance;

//==============================================================================
App::App() {
}

//------------------------------------------------------------------------------
//void App::OnEvent(SDL_Event* Event) {
//
//	if (Event->type == SDL_QUIT) Running = false;
//}

//------------------------------------------------------------------------------
bool App::init() {
	if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
		Log("Unable to Init SDL: %s", SDL_GetError());
		return false;
	}

	if(!SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1")) {
		Log("Unable to Init hinting: %s", SDL_GetError());
	}
	//avoids the SDL fake mouse events on touch events...
//    SDL_SetHint(SDL_HINT_ANDROID_SEPARATE_MOUSE_AND_TOUCH, "1");
	//for now just use the fake mouse events and repress touch events.
	//for multitouch etc.. got to use the actual touch events. (TODO)

    SDL_Rect gScreenRect = { 0, 0, 320, 240 };

    //Get device display mode
    SDL_DisplayMode displayMode;
    if( SDL_GetCurrentDisplayMode( 0, &displayMode ) == 0 )
    {
        gScreenRect.w = displayMode.w;
        gScreenRect.h = displayMode.h;
    }



#ifdef __ANDROID__
	actualWindowWidth = gScreenRect.w;
	actualWindowHeight = gScreenRect.h;

	if((window = SDL_CreateWindow(
		"My SDL Game",
		SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
        gScreenRect.w, gScreenRect.h, SDL_WINDOW_SHOWN)
	) == NULL) {
		Log("Unable to create SDL Window: %s", SDL_GetError());
		return false;
	}
#else
	actualWindowWidth = windowWidth;			//TODO what does gScreenRect mean in this context?
	actualWindowHeight = windowHeight;

	if ((window = SDL_CreateWindow(
		"My SDL Game",
		SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
		windowWidth, windowHeight, SDL_WINDOW_SHOWN)
		) == NULL) {
		Log("Unable to create SDL Window: %s", SDL_GetError());
		return false;
	}
#endif

    //does nothing couses "SDL Error: Renderer already associated with window" on android
	primarySurface = SDL_GetWindowSurface(window);

	if((renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED)) == NULL) {
	    Log("Unable to create renderer! SDL Error: %s\n", SDL_GetError() );
	    return false;
	}


	SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);





	// Initialize image loading for PNGs
	if(!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
		Log("Unable to init SDL_image: %s", IMG_GetError());
		return false;
	}

	//Initialize SDL_ttf
	if (TTF_Init() == -1)
	{
		printf("SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
		return false;
	}

	//Initialize SDL_mixer
	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0)
	{
		Log("Unable to init SDL_mixer: %s", Mix_GetError());
		return false;
	}

//moved to ImageBank call	// Load all of our Textures (see TextureBank class for expected folder)
//moved to ImageBank call	if(TextureBank::Init() == false) {
//moved to ImageBank call		Log("Unable to init TextureBank");
//moved to ImageBank call		return false;
//moved to ImageBank call	}



// Load all of our Textures (see TextureBank class for expected folder)
	if (SoundBank::Init() == false) {
		Log("Unable to init SoundBank");
		return false;
	}



	//Open the font
	TTF_Font* font = TTF_OpenFont("assets/Fonts/lazy.ttf", 28);
	if (font == NULL)
	{
		printf("Failed to load lazy font! SDL_ttf Error: %s\n", TTF_GetError());
		return false;
	}
	SDL_Color textColor = { 225, 0, 0 };


	Globals::window = window;
	Globals::renderer = renderer;
	Globals::font = font;
	Globals::textColor = textColor;




	
/*
// Exctract all defined images from loaded textures.
//	if (ImageBank::Init() == false) {
//		Log("Unable to init ImageBank");
//		return false;
//	}


	//nope .setImage(ImageBank::Get("nope1"));
	nope = new Nope();
	nope2.setImage(ImageBank::Get("nope2"));
	nope3.setImage(ImageBank::Get("nope2"));


	nope2.setParent(nope);
	nope3.setParent(&nope2);

	nope2.setLocalPosition(50, 50);
	nope3.setLocalPosition(0, 150);
*/


	initContainers();
	button1 = std::make_unique<Button>("EDITOR", font, textColor, renderer);
	//button1 = new Button("EDITOR", font, textColor, renderer);
	button1->setLocalPosition(windowWidth - 100, 20);
	button1->setInteractive(true);
	button1->setOnClick(std::bind(&App::buttonEditor_onClick, this) );
	//UI->addChild(std::move(button1)); //TODO test with smart (shared) ptr - better error? (button1=null)
	//UI->addChild(button1); 

	

//	for (int i = 0; i < 100000; i++) {
//		buttonEditor_onClick();
//	}


	ImageBank::Init();
	nope = new Nope();
//	nope->setMovement(0.2, 0);

	return true;


}



void App::initContainers()
{
	//UI = new Container();

	////std::shared_ptr<Button> btn, btn2, btn3;

	//Button* btn;

	//btn = new Button("1", Globals::font, Globals::textColor, Globals::renderer);
	////Button* pBtn = new Button("1", Globals::font, Globals::textColor, Globals::renderer);
	////btn = std::shared_ptr<pBtn>;
	////btn = std::make_shared<Button>("1", Globals::font, Globals::textColor, Globals::renderer);
	//btn->setOnClick(std::bind(&App::btnOpenLevel1_onClick, this));
	//btn->setLocalPosition(0, 0);
	//UI->addChild(btn);

	//btn = new Button("2", Globals::font, Globals::textColor, Globals::renderer);
	//btn->setOnClick(std::bind(&App::btnOpenLevel2_onClick, this));
	//btn->setLocalPosition(0, 30);
	//UI->addChild(btn);

	//btn = new Button("3", Globals::font, Globals::textColor, Globals::renderer);
	//btn->setOnClick(std::bind(&App::btnOpenLevel3_onClick, this));
	//btn->setLocalPosition(0, 60);
	////UI->addChild(btn);
	//UI->addChild(btn);

	//UI->setLocalPosition(0, 100);



	UI = new Container();

	//std::shared_ptr<Button> btn, btn2, btn3;

	std::unique_ptr<Button> btn;

	//std::unique_ptr<Button> btn1
	btn = std::make_unique<Button>("1", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&App::btnOpenLevel1_onClick, this));
	btn->setLocalPosition(0, 0);
	UI->addChild( std::move(btn) );

	btn = std::make_unique<Button>("2", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&App::btnOpenLevel2_onClick, this));
	btn->setLocalPosition(0, 30);
	UI->addChild(std::move(btn));

	btn = std::make_unique<Button>("3", Globals::font, Globals::textColor, Globals::renderer);
	btn->setInteractive(true);
	btn->setOnClick(std::bind(&App::btnOpenLevel3_onClick, this));
	btn->setLocalPosition(0, 60);
	//UI->addChild(btn);
	UI->addChild(std::move(btn));

	UI->setLocalPosition(0, 100);
}

void App::resetContainers()
{
	if (levelContainer) {
		levelContainer->deleteAllContents();
		delete levelContainer;
//		pLevelContainer = NULL;
		levelContainer = NULL;
	}
	if (UI) {
		UI->deleteAllContents();
		delete UI;
		UI = NULL;
	}
}
//------------------------------------------------------------------------------
void App::loop() {
	interactionManager.update();
	if (editingMode) {
		imageEditor->update();
	}
	else {
		if (controllingSprite) {
			const Uint8* currentKeyStates = SDL_GetKeyboardState(NULL);
			if (currentKeyStates[SDL_SCANCODE_UP])			{ controllingSprite->moveLocalPosition( 0, -1); }
			else if (currentKeyStates[SDL_SCANCODE_DOWN])	{ controllingSprite->moveLocalPosition( 0,	1); }
			else if (currentKeyStates[SDL_SCANCODE_LEFT])	{ controllingSprite->moveLocalPosition(-1,  0); }
			else if (currentKeyStates[SDL_SCANCODE_RIGHT])	{ controllingSprite->moveLocalPosition( 1,  0); }
			//else { currentTexture = &gPressTexture; }
		}
	}

	if (nope)
		nope->update();

	if (levelContainer) 
		levelContainer->update();
}

//------------------------------------------------------------------------------
void App::render() {
	SDL_RenderClear(renderer);

	//todo make switch and mode ENUM
	if (editingMode) {
		imageEditor->render();
	}
	else {
		if (levelContainer) 
			levelContainer->render();
		if (UI) UI->render();
	}

	if(button1)
		button1->render();
	if (nope)
		nope->render();
	SDL_RenderPresent(renderer);

}
//------------------------------------------------------------------------------
void App::OnExit() {
	Log("Quitting!");
	running = false;
}


void App::OnKeyDown(SDL_Keysym sym) {
	switch(sym.sym)
	{
        case SDLK_UP:
//			nope->addMovement(0, -1);
			break;

		case SDLK_DOWN:
//			nope->addMovement(0, 1);
			break;

		case SDLK_LEFT:
//			nope->addMovement(-1, 0);
			break;

		case SDLK_RIGHT:
//			nope->addMovement(1, 0);
			break;

		default:
			Log("keyDown_default");
			break;
	}


	
}

void App::OnKeyUp(SDL_Keysym sym) {
//	nope->setMovement(0, 0);
	Log("OnKeyUp!");

	switch (sym.sym)
	{

	case SDLK_UP:
//		nope->addMovement(0, 1);
		break;

	case SDLK_DOWN:
//		nope->addMovement(0, -1);
		break;

	case SDLK_LEFT:
//		nope->addMovement(1, 0);
		break;

	case SDLK_RIGHT:
//		nope->addMovement(-1, 0);
		break;



	case SDLK_0:
		SoundBank::toggleMusic();
		break;
	case SDLK_1:
		if (SoundBank::GetMusic("1")) { SoundBank::GetMusic("1")->play(); }
		break;
	case SDLK_2:
		if (SoundBank::GetMusic("2")) { SoundBank::GetMusic("2")->play(); }
		break;
	default:
		break;
	}
}

void App::OnLButtonDown(int x, int y) {
	Log("OnLButtonDown: %i,%i", x, y);
    return;
//	camera.moveLocalPosition(5, 5);
//	nope->setLocalScale(1);

    if (x < actualWindowWidth/2 && y < actualWindowHeight/2) {
        Log("UP_LEFT");
 //       nope->addMovement(-1, -1);
    }
    if (x > actualWindowWidth/2 && y > actualWindowHeight/2) {
        Log("DOWN_RIGHT");
 //       nope->addMovement(1, 1);
    }
    if (x > actualWindowWidth/2 && y < actualWindowHeight/2) {
        Log("UP_RIGHT");

        switch (testInt) {
            case 0:
                SoundBank::toggleMusic();
                testInt = 1;
                break;
            case 1:
                if (SoundBank::GetMusic("1")) { SoundBank::GetMusic("1")->play(); }
                testInt = 2;
                break;
            case 2:
                if (SoundBank::GetMusic("2")) { SoundBank::GetMusic("2")->play(); }
                testInt = 0;
                break;
            default:
                testInt = 0;
                break;
        }

    }
}
void App::OnRButtonDown(int x, int y) {
	Log("OnRButtonDown: %i,%i", x, y);
	nope->setLocalScale(2);
}
void App::OnLButtonUp(int x, int y) {
	Log("OnLButtonUp: %i,%i", x, y);
}
void App::OnTouchDown(double x, double y) {
	Log("OnTouchDown: %f,%f", x * actualWindowWidth, y * actualWindowHeight);
}


void App::OnTouchUp(double x, double y) {
	Log("OnTouchUp: %f,%f", x, y);


	//nope->setMovement(0, 0);

}


void App::OnMouseWheel(int x, int y) {
	double rotation = (double)y/20;
	nope->addLocalRotation(rotation);

}

//------------------------------------------------------------------------------
void App::cleanup() {
	TextureBank::Cleanup();

	if(renderer) {
		SDL_DestroyRenderer(renderer);
		renderer = NULL;
	}

	if(window) {
		SDL_DestroyWindow(window);
		window = NULL;
	}


	TTF_Quit();
	IMG_Quit();
	SDL_Quit();
}

//------------------------------------------------------------------------------
int App::execute(int argc, char* argv[]) {
	if (!init()) {
		Log("Init failed Press ENTER key to exit");
//#ifdef _WIN32
		std::cin.get();
//#endif 
		return 0;
	}
	SDL_Event Event;

	while(running) {
		while(SDL_PollEvent(&Event) != 0) {
			if (Event.type == SDL_QUIT) { OnExit(); }

			interactionManager.OnEvent(&Event);
			if (editingMode) {
				imageEditor->OnEvent(&Event);
			}
			else {
				OnEvent(&Event);
			}
		}
	//	SDL_PumpEvents();

		loop();
		render();

		SDL_Delay(1); // Breath
	}

	cleanup();

	return 1;
}






//std::function<void(void)> App::button1Pressed() {
void App::buttonEditor_onClick() {

	if (editingMode) {
		initContainers();
		button1->setText("EDITOR");
		delete imageEditor;
		editingMode = false;
	}
	else {
		resetContainers();
		button1->setText("PLAYER");
		imageEditor = new ImageEditor(renderer);
		editingMode = true;
		//imageEditor->openImage();
	}
}







void App::openLevel(int level)
{
	if (levelContainer) {
	//	pLevelContainer = NULL;
		levelContainer->deleteAllContents();
		delete levelContainer; //TODO make levelContainer smart...?
		levelContainer = NULL;
	}
	//TODO use pLevelContainer, remove levelContainer
	pLevelContainer = LevelManager::openLevel(level);//needed to keep reference
	levelContainer = pLevelContainer.get();// LevelManager::openLevel(level).get();
	//TODO
	if (!levelContainer) {
		Log("Error: No level data returned");
		return;
	}

	//set onClick for all objects to controll that one.
	for (auto container : levelContainer->getAllChildren_smart()) {
		Sprite* sprite = dynamic_cast<Sprite*> (container);
		if (sprite) { // is child is object of Sprite
			sprite->setInteractive(true);
			sprite->setOnClick(std::bind(&App::character_onClick2, this));
			sprite->setOnClick_returnSelf(std::bind(&App::character_onClick, this, std::placeholders::_1));

			/*std::function<void(void)> f = std::bind(&App::character_onClick, this);
			sprite->setOnClick(f);

			std::function<void(Sprite*)> f2 = [=](Sprite* sprite) {
				this->character_onClick2(sprite);
			};
			sprite->setOnClick(f2);*/
		}
	}

}


void App::character_onClick(Sprite* sprite)
{
	Log("blabla");
	controllingSprite = sprite;
}
void App::character_onClick2()
{
	Log("blabla2");
}

void App::btnOpenLevel1_onClick()
{
//	editingUI.removeChild(&openLevelMenu);
	openLevel(1);
}
void App::btnOpenLevel2_onClick()
{
//	editingUI.removeChild(&openLevelMenu);
	openLevel(2);
}
void App::btnOpenLevel3_onClick()
{
//	editingUI.removeChild(&openLevelMenu);
	openLevel(3);
}



//==============================================================================
SDL_Renderer* App::getRenderer() { return renderer; }
SDL_Surface* App::getPrimarySurface() { return primarySurface; }
InteractionManager* App::getInteractionManager() { return &interactionManager; }

//==============================================================================
App* App::getInstance() { return &App::Instance; }

int App::GetWindowWidth()  { return windowWidth; }
int App::GetWindowHeight() { return windowHeight; }

//==============================================================================
