#include "Vector2.h"
#include <math.h>


Vector2::Vector2() {
	x = 0;
	y = 0;
}

Vector2::Vector2(double _x, double _y) {
	x = _x;
	y = _y;
}
Vector2::Vector2(double _xy) {
	x = _xy;
	y = _xy;
}

//TODO sould be pointers with new Vector2(x + vec.x, y + vec.y);?
Vector2 Vector2::add(Vector2 vec) {
	return Vector2(x + vec.x, y + vec.y);
}
Vector2 Vector2::add(double x, double y) {
	Vector2 vec = Vector2(x, y);
	return add(vec);
}
Vector2 Vector2::sub(Vector2 vec) {
	return Vector2(x - vec.x, y - vec.y);
}
Vector2 Vector2::sub(double x, double y) {
	Vector2 vec = Vector2(x, y);
	return sub(vec);
}
Vector2 Vector2::mult(double value){
    return Vector2(x * value, y * value);
}
Vector2 Vector2::div(double value){
    return mult(1 / value);
}

double Vector2::dot(Vector2 vec){
    return x * vec.x + y * vec.y;
}

void Vector2::set(Vector2 vec) {
	set(vec.x, vec.y);
}
void Vector2::set(double _x, double _y) {
	x = _x;
	y = _y;
}


void Vector2::normalize(){
    length = 1;
}


double Vector2::get_length_fast() {
	return x * x + y * y;
}

double Vector2::get_length() {
    return sqrt(x * x + y * y);
}

double Vector2::set_length(double length) {
    double currentLength = get_length();
    if (currentLength == 0) return 0;
    double mul = length / currentLength;
    x *= mul;
    y *= mul;
    return length;
}

//returns angle relative to X-axis
//	------>  is angle=0
double Vector2::get_angle() {
	//return atan(y / x);
	return atan2(y, x);
}