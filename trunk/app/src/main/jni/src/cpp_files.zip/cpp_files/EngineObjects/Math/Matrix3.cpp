#include "Matrix3.h"

#include <math.h>
#include <iostream>

#include "../../Helpers/Log.h"

Matrix3::Matrix3() :
_00(1), _10(0), _20(0),
_01(0), _11(1), _21(0),
_02(0), _12(0), _22(1) 
{

}

Matrix3::Matrix3(double __00, double __10, double __20,
			     double __01, double __11, double __21,
			     double __02, double __12, double __22 ) :

_00(__00), _10(__10), _20(__20),
_01(__01), _11(__11), _21(__21),
_02(__02), _12(__12), _22(__22)
{				

}


Matrix3 Matrix3::translation(double x, double y) {
	return Matrix3(
		1, 0, x,
		0, 1, y,
		0, 0, 1
	);
}

Matrix3 Matrix3::scale(double x, double y) {
	return Matrix3(
		x, 0, 0,
		0, y, 0,
		0, 0, 1
	);
}

Matrix3 Matrix3::rotation(double alpha) {
	return Matrix3(
		cos(alpha), -sin(alpha), 0,
		sin(alpha),  cos(alpha), 0,
		0, 0, 1
	);
}








Vector2 Matrix3::multvec(Vector2 value) {
	//var product = new Vector2(0, 0);
	double w = _02 * value.x + _12 * value.y + _22 * 1;
	double x = (_00 * value.x + _10 * value.y + _20 * 1) / w;
	double y = (_01 * value.x + _11 * value.y + _21 * 1) / w;
//	std::cout << w;
	return Vector2(x, y);
}

Matrix3 Matrix3::multmat(Matrix3 m) {
	return Matrix3(
		_00 * m._00 + _10 * m._01 + _20 * m._02, _00 * m._10 + _10 * m._11 + _20 * m._12, _00 * m._20 + _10 * m._21 + _20 * m._22,
		_01 * m._00 + _11 * m._01 + _21 * m._02, _01 * m._10 + _11 * m._11 + _21 * m._12, _01 * m._20 + _11 * m._21 + _21 * m._22,
		_02 * m._00 + _12 * m._01 + _22 * m._02, _02 * m._10 + _12 * m._11 + _22 * m._12, _02 * m._20 + _12 * m._21 + _22 * m._22
	);
}



Matrix3 Matrix3::inverse() {

	double c00 = cofactor(_11, _21, _12, _22);
	double c01 = cofactor(_10, _20, _12, _22);
	double c02 = cofactor(_10, _20, _11, _21);

	double det = _00 * c00 - _01 * c01 + _02 * c02;
	if (fabs(det) < 0.000001) {
		throw "determinant is too small";
	}

	double c10 = cofactor(_01, _21, _02, _22);
	double c11 = cofactor(_00, _20, _02, _22);
	double c12 = cofactor(_00, _20, _01, _21);

	double c20 = cofactor(_01, _11, _02, _12);
	double c21 = cofactor(_00, _10, _02, _12);
	double c22 = cofactor(_00, _10, _01, _11);

	double invdet = 1.0 / det;

	return Matrix3(
		 c00 * invdet, -c01 * invdet,  c02 * invdet,
		-c10 * invdet,  c11 * invdet, -c12 * invdet,
		 c20 * invdet, -c21 * invdet,  c22 * invdet
	);

}

double Matrix3::cofactor(double m0, double m1, double m2, double m3){
	return m0 * m3 - m1 * m2;
}