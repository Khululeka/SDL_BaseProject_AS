#include "LevelManager.h"
#include "../Helpers/Log.h"
#include "ImageBank.h"
//#include "../Helpers/ConvertFunctions.h"
#include "../Helpers/Stringify.h"
#include "../EngineObjects/Sprite.h"



#include "../Helpers/INIReader.h"


#include <iostream>
#include <stdexcept>
#include <string>

#include <functional>


#include "../EngineObjects/Animation_Waggle.h"

//for std::isspace
#include <algorithm> 
#include <cctype>
#include <locale>

//LevelManager::LevelManager()
//{
//
//}
//
//LevelManager::~LevelManager()
//{
//
//}



void LevelManager::initMap() {

//	s_mapObjectProperties["x"] = LEVEL_MANAGER_OBJECT_PROPERTIES_X;
//	s_mapObjectProperties["y"] = LEVEL_MANAGER_OBJECT_PROPERTIES_Y;

}


/*
Container LevelManager::openLevel(int level)
{
	//initMap();

	//todo why not work with s_mapObjectProperties in the header?
	//TODO use defines
	static std::map<std::string, objectProperties> s_mapObjectProperties;
	s_mapObjectProperties["x"] = LEVEL_MANAGER_OBJECT_PROPERTIES_X;
	s_mapObjectProperties["y"] = LEVEL_MANAGER_OBJECT_PROPERTIES_Y;

	Container levelContainer;

	std::string path = "assets\\UserData\\Levels\\" + int2string(level);
	std::string configPath = path + "\\config.ini";

	Log("Path: %s", path.c_str());


	//load config.ini
	boost::property_tree::ptree pt;
	try {
		boost::property_tree::ini_parser::read_ini(configPath, pt);
	}
	catch (const std::exception& e) {
		Log("couldn't read config.ini. Error <%s>", e.what() );
		//std::cerr << e.what() << std::endl;
		//if (std::string const * extra = boost::get_error_info<my_tag_error_info>(e)) {
		//	std::cout << *extra << std::endl;
		//}
		return levelContainer; 
		//TODO instead of abort, create config.ini with zero values and continue...
	}

	//load images
	if (ImageBank::loadFolder(path) == false) {
		Log("ERROR: Unable to init ImageBank");
		return levelContainer;
	}


	Image* image;
	Sprite* sprite;
	for (auto& section : pt)
	{
		std::cout << '[' << section.first << "]\n";
		image = ImageBank::Get(section.first);
		if (image) {
			sprite = new Sprite(image);
			levelContainer.addChild(sprite);
			sprite->draggable = true;

			//std::string strX = section.first + ".x";
			//int x = pt.get(strX, 0);
			int x, y = 0;
			//int y = 0;

			//x = pt.get<int>(strX);
			//Log("x: %i", x);

			for (auto& key : section.second) {
				std::cout << key.first << "=" << key.second.get_value<std::string>() << "\n";
				std::string k = key.first;
				switch (s_mapObjectProperties[key.first]) {
				case LEVEL_MANAGER_OBJECT_PROPERTIES_X:
					x = key.second.get_value<int>();
					break;
				case LEVEL_MANAGER_OBJECT_PROPERTIES_Y:
					y = key.second.get_value<int>();
					break;

				default:
					Log("unknown section key: <%s>", key.first.c_str() );
					break;
				}
			}

			Log("x: %i, y: %i", x, y);
			sprite->setLocalPosition(x, y);

		} else {
			Log("No image found with config section: <%s>", section.first.c_str() );
		}

	}



	//std::vector<Image*> images = ImageBank::getImageList();
	//for (auto image : images) {
	//	Sprite* sprite = new Sprite(image);
	//	levelContainer.addChild(sprite);
	//	sprite->draggable = true;
	//}



	return levelContainer;

}
*/




std::unique_ptr<Container> LevelManager::openLevel(int level)
{
	//initMap();

	//todo why not work with s_mapObjectProperties in the header?
	static std::map<std::string, objectProperties> s_mapObjectProperties;
	s_mapObjectProperties["type"] = LEVEL_MANAGER_OBJECT_PROPERTIES_TYPE;
	s_mapObjectProperties["x"] = LEVEL_MANAGER_OBJECT_PROPERTIES_X;
	s_mapObjectProperties["y"] = LEVEL_MANAGER_OBJECT_PROPERTIES_Y;
	s_mapObjectProperties["animations"] = LEVEL_MANAGER_OBJECT_PROPERTIES_ANIMATIONS;

	//Container* levelContainer = new Container();
	std::unique_ptr<Container> levelContainer = std::make_unique<Container>();

	//std::string path = "assets\\UserData\\Levels\\" + int2string(level);
	std::string path = "assets\\UserData\\Levels\\" + Stringify::toString(level);
	std::string configPath = path + "\\config.ini";

	Log("Path: %s", path.c_str());


	//load config.ini
	INIReader reader(configPath);
	if (reader.ParseError() < 0) {
		Log("couldn't read config.ini. Error<%i>", reader.ParseError() );
		return std::unique_ptr<Container>(nullptr);
	}

	//load images
	if (ImageBank::loadFolder(path) == false) {
		Log("ERROR: Unable to init ImageBank");
		return std::unique_ptr<Container>(nullptr);
	}


//	auto bgSection = pt.get_child("background");
//	int layers = bgSection.get<int>("layers");
//	if (layers > 0) {
//		Log("blablabla");
//	}

	try {

		Image* image;
		std::unique_ptr<Sprite> sprite;
		for (auto& section : reader.Sections() )
		{
			//std::string type = section.second.get<std::string>("type");
			std::string type = reader.Get(section, "type", "UNKNOWN");
			Log("type=");
			Log("%s", type.c_str());
			//TODO now bgs have to be on top if file
			if (type == "background") {	//TODO make switch and make define or ENUM
				Log("making background");
				image = ImageBank::Get(section);
				std::unique_ptr<BasicSprite> basicSprite;
				basicSprite = std::make_unique<BasicSprite>(image);
				levelContainer->addChild(std::move(basicSprite));
			}
			else if (type == "PC") {

				std::cout << '[' << section << "]\n";
				image = ImageBank::Get(section);
				if (image) {
					sprite = std::make_unique<Sprite>(image);

					//std::string strX = section.first + ".x";
					//int x = pt.get(strX, 0);
					int x, y = 0;


						//case LEVEL_MANAGER_OBJECT_PROPERTIES_X:
					x = reader.GetInteger(section, "x", 0);
				//		case LEVEL_MANAGER_OBJECT_PROPERTIES_Y:
					y = reader.GetInteger(section, "y", 0);

				//		case LEVEL_MANAGER_OBJECT_PROPERTIES_ANIMATIONS:
				//		{
					std::string namesCSV = reader.Get(section, "animations", "");
					std::vector<std::string> names;

					//split CSV string
					//boost::split(names, namesCSV, [](char c) {return c == ','; });
	//				names = Stringify::split(namesCSV, ",");
					//trim names of leading and trailing spaces
					for (auto &s : names) {
						//trim(animations); //todo use this instead of next line (where to put it?)  https://stackoverflow.com/questions/216823/whats-the-best-way-to-trim-stdstring?utm_medium=organic&utm_source=google_rich_qa&utm_campaign=google_rich_qa
						s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](int c) {return !std::isspace(c); }));
					}



					for (auto &name : names) {
						//std::string id = pt.get<std::string>(name + ".id");
						std::string id = reader.Get(name, "id", "UNKNOWN");
						//std::string animation_type = pt.get<std::string>(name + ".type");
						std::string animation_type = reader.Get(name, "type", "UNKNOWN");
						if (animation_type == "Animation_Waggle") {
							std::string speed = reader.Get(name, "speed", "UNKNOWN");
							std::string amplitude = reader.Get(name, "amplitude", "UNKNOWN");
							//sprite->animationMap[id] = (std::make_unique<Animation_Waggle>(id, sprite.get(), string2int(speed), string2double(amplitude, 2) ));
							sprite->animationMap[id] = (std::make_unique<Animation_Waggle>(id, sprite.get(), Stringify::ToInt(speed), Stringify::ToDouble(amplitude)));
						}
					}
					


					//sprite->animationMap["idle"] = (std::make_unique<Animation_Waggle>("idle", sprite.get(), 100, 0.2));
					sprite->startAnimation("idle");


					//	sprite->draggable = true;
					Log("x: %i, y: %i", x, y);
					sprite->setLocalPosition(x, y);
					levelContainer->addChild(std::move(sprite));

				}
				else { //if (image) == false
					Log("No image found with config section: <%s>", section.c_str());
				}
			}
			else {
				Log("unknown type: <%s>. ignored", type.c_str());
			}

		}
	}
	catch (const std::exception& e) {
		Log("Incorrectly formatted INI file. Error <%s>", e.what());
		return std::unique_ptr<Container>(nullptr);
		//TODO instead of abort, fill in ini file with defaults
	}



	//std::vector<Image*> images = ImageBank::getImageList();
	//for (auto image : images) {
	//	Sprite* sprite = new Sprite(image);
	//	levelContainer.addChild(sprite);
	//	sprite->draggable = true;
	//}



	return levelContainer;

}

////    
////    
////    //not this one OBSOLETE
////    void LevelManager::saveLevel(int level, std::vector<BasicSprite> characters)
////    {
////    	//initMap();
////    	//todo why not work with s_mapObjectProperties in the header?
////    	static std::map<std::string, objectProperties> s_mapObjectProperties;
////    	s_mapObjectProperties["type"] = LEVEL_MANAGER_OBJECT_PROPERTIES_TYPE;
////    	s_mapObjectProperties["x"] = LEVEL_MANAGER_OBJECT_PROPERTIES_X;
////    	s_mapObjectProperties["y"] = LEVEL_MANAGER_OBJECT_PROPERTIES_Y;
////    	s_mapObjectProperties["animations"] = LEVEL_MANAGER_OBJECT_PROPERTIES_ANIMATIONS;
////    
////    
////    	boost::property_tree::ptree pt;
////    	for (auto sprite : characters) {
////    	std::string section = sprite.getID();
////    		pt.put(section + ".x", sprite.getLocalPosition().x );
////    		pt.put(section + ".y", sprite.getLocalPosition().y );
////    	}
////    
////    	//std::string path = "assets\\UserData\\Levels\\" + int2string(level);
////    	std::string path = "assets\\UserData\\Levels\\" + Stringify::toString(level);
////    	std::string configPath = path + "\\config.ini";
////    	boost::property_tree::write_ini(configPath, pt);
////    
////    }
////    
////    

void LevelManager::saveLevel(int level, Container characters)
{
	//initMap();
	//todo why not work with s_mapObjectProperties in the header?
	static std::map<std::string, objectProperties> s_mapObjectProperties;
	s_mapObjectProperties["x"] = LEVEL_MANAGER_OBJECT_PROPERTIES_X;
	s_mapObjectProperties["y"] = LEVEL_MANAGER_OBJECT_PROPERTIES_Y;


////	boost::property_tree::ptree pt;
////	for (auto character : characters.getAllChildren_smart() ) {
////		BasicSprite* sprite = dynamic_cast<BasicSprite*> (character);
////		if (sprite) { // check if parent's class is Container
////		std::string section = sprite->getID();
////			pt.put(section + ".x", sprite->getLocalPosition().x);
////			pt.put(section + ".y", sprite->getLocalPosition().y);
////		}
////	}
////
////	//std::string path = "assets\\UserData\\Levels\\" + int2string(level);
////	std::string path = "assets\\UserData\\Levels\\" + Stringify::toString(level);
////	std::string configPath = path + "\\config.ini";
////	boost::property_tree::write_ini(configPath, pt);

}