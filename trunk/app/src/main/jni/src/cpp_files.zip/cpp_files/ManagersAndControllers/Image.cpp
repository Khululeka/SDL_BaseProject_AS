//==============================================================================
#include "Image.h"
#include "../Helpers/Log.h"




//==============================================================================
//Image::Image() {
//}
Image::Image(std::string _id, Texture* _tx) :
	id(_id),
	tx(_tx),
	//txRect(NULL),
	txRect({ 0, 0, _tx->Width, _tx->Height } ),
	width(_tx->Width),
	height(_tx->Height)
{

}

Image::Image(std::string _id, Texture* _tx, SDL_Rect _txRect) :
id(_id),
tx(_tx),
txRect(_txRect),
width(_txRect.w),
height(_txRect.h)
{

}

Image::~Image() {
}

void Image::setTexture(Texture* _tx) {
	tx = _tx;
	width = tx->GetWidth();
	height = tx->GetHeight();
}

void Image::render(int x, int y) {
	tx->Render(x, y, width, height, txRect);
}
void Image::renderEx(int x, int y, double rotation) {
	tx->RenderEx(x, y, width, height, txRect, rotation);
}
void Image::renderEx(int x, int y, int width, int height, double rotation) {
	tx->RenderEx(x, y, width, height, txRect, rotation);
}


int Image::getWidth() {
	return width;
}
int Image::getHeight() {
	return height;
}

//void Image::setPath(std::string _path) {
//	path = _path;
//}
//std::string Image::getPath() {
//	return path;
//}