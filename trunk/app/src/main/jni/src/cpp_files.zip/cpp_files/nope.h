#pragma once

#include "EngineObjects/Sprite.h"
#include "EngineObjects/Animation_Sequence.h"

enum animations {
	ANIM_IDLE,
	ANIM_WALKING,
	ANIM_TOTAL_ITEMS
};

enum sounds {
	SOUND_WALKING,
	SOUND_TOTAL_ITEMS
};

class Nope : public Sprite {

public:

	Nope();
	~Nope();

	void setup();
	void update();
	void setMovement(Vector2 movement);
	void setMovement(double x, double y);
	void addMovement(Vector2 movement);
	void addMovement(double x, double y);
	void control();
	void checkMoving();

	int speed;
	//ofImage animationImages[1];
//	int x;
//	int y;
//	int vx;
//	int vy;
	Vector2 v;

	bool moving;
};
